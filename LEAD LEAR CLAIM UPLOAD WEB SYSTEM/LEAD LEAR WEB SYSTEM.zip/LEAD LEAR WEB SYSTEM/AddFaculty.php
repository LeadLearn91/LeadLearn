
<!DOCTYPE html>
<head>
	<meta charset="UTF-8" />
    <title>Leed Learn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
    <script src="js/LoginCheck.js" type="text/javascript"></script>
    <script type="text/javascript">
		function ValidateRegForm()
		{
			/*Assigne input values into variable*/
            
			var TempFacIdValidete = document.RegFrm.FacId.value;
			var TempFacCorIdValidate = document.RegFrm.FacCorId.value;						
			var TempFacNameValidate=document.RegFrm.FacName.value;
			var TempFacSectionValidate=document.RegFrm.FacSection.value;
			
			
              
			/*check conditions*/
			
			var numeric = /^[0-9]+$/;
            var alpha = /^[a-zA-Z]+$/;
			
            
			/*validate Customer NIC Number text field*/
			if (TempFacIdValidete.match(" "))
	        {
				
				alert("faculty out of fleld. Check and enter again");
			    document.getElementById("FacId").style.backgroundColor = '#f44336';
			    document.getElementById("FacId").style.color = 'black';			
				document.getElementById("FacId").value = "";				
			    document.getElementById("FacId").focus();			  
			    return false;
			}
			else if (TempFacIdValidete.match(numeric))
	        {
				
				alert(" Incorrect id formate insertion");
			    document.getElementById("FacId").style.backgroundColor = '#f44336';
			    document.getElementById("FacId").style.color = 'black';			
				document.getElementById("FacId").value = "";				
			    document.getElementById("FacId").focus();			  
			    return false;
			}
			else if (TempFacIdValidete.length>=12)
	        {
				
				alert("faculty id must have 5 - 12");
			    document.getElementById("FacId").style.backgroundColor = '#f44336';
			    document.getElementById("FacId").style.color = 'black';			
				document.getElementById("FacId").value = "";				
			    document.getElementById("FacId").focus();			  
			    return false;
			}
			else if (TempFacIdValidete.length<5)
	        {
				
				alert("Faculty id must have 5 - 12");
			    document.getElementById("FacId").style.backgroundColor = '#f44336';
			    document.getElementById("FacId").style.color = 'black';			
				document.getElementById("FacId").value = "";				
			    document.getElementById("FacId").focus();			  
			    return false;
			}
			
			 
			
			// validate pasword text field
			
			else if (TempFacNameValidate.match(" "))
	        {
				
				alert("Faculty name out of field");
			    document.getElementById("FacName").style.backgroundColor = '#f44336';
			    document.getElementById("FacName").style.color = 'black';			
				document.getElementById("FacName").value = "";				
			    document.getElementById("FacName").focus();			  
			    return false;
			}	
				else if (TempFacNameValidete.match(numeric))
	        {
				
				alert(" Incorrect faculty name inserssion formate");
			    document.getElementById("FacName").style.backgroundColor = '#f44336';
			    document.getElementById("FacName").style.color = 'black';			
				document.getElementById("FacName").value = "";				
			    document.getElementById("FacName").focus();			  
			    return false;
			}	
			else if (TempFacNameValidate.length>50)
	        {
				
				alert("Faculty name between 10 - 50");
			    document.getElementById("FacName").style.backgroundColor = '#f44336';
			    document.getElementById("FacName").style.color = 'black';			
				document.getElementById("FacName").value = "";				
			    document.getElementById("FacName").focus();			  
			    return false;
			}
			else if (TempFacNameValidate.length<10)
	        {
				
				alert("faculty name between 10 - 50 ");
			    document.getElementById("FacName").style.backgroundColor = '#f44336';
			    document.getElementById("FacName").style.color = 'black';			
				document.getElementById("FacName").value = "";				
			    document.getElementById("FacName").focus();			  
			    return false;
			}
			// validate pasword text field
			
			// validate pasword text field
			
			else if (TempFacSectionValidate.match(" "))
	        {
				
				alert("Faculty section out of field");
			    document.getElementById("FacSection").style.backgroundColor = '#f44336';
			    document.getElementById("FacSection").style.color = 'black';			
				document.getElementById("FacSection").value = "";				
			    document.getElementById("FacSection").focus();			  
			    return false;
			}	
				else if (TempFacSectionValidete.match(numeric))
	        {
				
				alert(" Incorrect faculty secssion inserssion formate");
			    document.getElementById("FacSection").style.backgroundColor = '#f44336';
			    document.getElementById("FacSection").style.color = 'black';			
				document.getElementById("FacSection").value = "";				
			    document.getElementById("FacSection").focus();			  
			    return false;
			}	
			else if (TempFacSectionValidate.length>40)
	        {
				
				alert("Faculty secssion between 10 - 40");
			    document.getElementById("FacSection").style.backgroundColor = '#f44336';
			    document.getElementById("FacSection").style.color = 'black';			
				document.getElementById("FacSection").value = "";				
			    document.getElementById("FacSection").focus();			  
			    return false;
			}
			else if (TempFacSectionValidate.length<10)
	        {
				
				alert("faculty secssion between 10 - 40 ");
			    document.getElementById("FacSection").style.backgroundColor = '#f44336';
			    document.getElementById("FacSection").style.color = 'black';			
				document.getElementById("FacSection").value = "";				
			    document.getElementById("FacSection").focus();			  
			    return false;
			}
			else
			{			  
			   return true;
			}
			}
			</script>

</head>
	<body>
    
    	<div class="container">
        <!-- Codrops top bar -->
        	<div class="codrops-top">
            	<span class="right">
                  <?php
	                
					$_POST['FacCorId']=$_GET['p'];
					
	              ?> 
                </span>
            <div class="clr"></div>
            </div><!--/ Codrops top bar -->
      	<header>
        <br/>
        	<h1>Register New Faculty <span> -University System</span></h1>
    </header>
        
        <section>				
<div id="container_demo" >
            	<a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                	<div id="login" class="animate form">
                    	<form method="post" name="RegFrm" id="loginFrm">      
                       <h1>New faculty</h1> 
  <p> 
                                <label for="SheduleId" class="uname" data-icon="S" >Faculty Id </label>
                                <input id="FacId" name="FacId" type="text"onBlur="checkAvailability()" value="<?php echo $_POST['FacId']?>"/> <span id="user-availability-status"></span>
                            </p>
                            <p> 
                                <label for="ECSID" class="uname" data-icon="u" > Add Faculty Coordinator</label>
                                <input id="FacCorId" name="FacCorId" type="text" onBlur="checkAvailability()"  readonly="readonly " value="<?php echo $_POST['FacCorId'] ?>"/> <span id="user-availability-status" ></span>
                                <label for="ECSID" class="uname" data-icon="u" > Serch available Faculty coordinator <a href="ViewCoordinatorList.php?">Sreach</a></label>
                            </p>
                            
                            <p> 
                                <label for="StDate" class="youpasswd" data-icon="p"> Name </label>
                                <input id="FacName" name="FacName" type="text" value="<?php echo $_POST['FacName']?>" /> 
                            </p>
                            <p> 
                                <label for="EndDate" class="youpasswd" data-icon="p">Section</label>
                                <input id="FacSection" name="FacSection" type="text" value="<?php echo $_POST['FacSection']?>" /> 
                            </p>
                            
                            <p>&nbsp;</p>
<p class="keeplogin"> 
                                <input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
                                <label for="loginkeeping">Keep me logged in</label>
                            </p>
                            
                            <p class="login button">
                              <input type="submit" name="Submit" value="Submit"  onClick="return ValidateRegForm()" />
                            </p>
                          <?php
     			 if (isset($_POST["Submit"]))
      			 {		      		
					// initialize the variable using above insertion
				    												
					$TempFacId=$_POST['FacId'];
					$TempFacCorId=$_POST['FacCorId'];
					$TempFacName=$_POST['FacName'];
					$TempFacSection=$_POST['FacSection'];
					
					
				
					//$PassStudentNICNo1=base64_encode($PassStudentLoginNICNumber);													
					//connect to the database
					$ServerConnection = mysql_connect('localhost','root','123456789');			
			  		//check connection successful
               		if(!$ServerConnection)
					{?>
						<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
					}
					else
					{
					  //connect to the data base
					  $DatabaseConnection = mysql_select_db("lldb")  ;
					  if(!$DatabaseConnection)
					  {?>
						<script type="text/javascript">alert("Could not connect to the Database")</script><?php
					  }
					  else
					  {
					    $InsertCustomerDetails=mysql_query("insert into faculty values('$TempFacId','$TempFacCorId','$TempFacName','$TempFacSection')");
						 if(!$InsertCustomerDetails)
						 {?>
							 <script type="text/javascript">
							  alert("this assignment item alredy existing. Enter correct shedule")
							  document.getElementById("SheduleId").style.backgroundColor = '#00E676';
			    			  document.getElementById("SheduleId").style.color = 'black';			
							  document.getElementById("SheduleId").value = "";				
			    			  document.getElementById("SheduleId").focus();
                             </script><?php
						  }
						  else
						 {?>
						   <script type="text/javascript">alert("Assignment item is added")</script><?php
							// insert data into login table
							$type='Student';
							 $InsertCustomerDetails=mysql_query("insert into logintbl values('$PassStdNicNumber','$PassUserName','$PassPassword','$type')");						 
							 
															
						}
          			 }															
				   }
														//close the opend database 
														//mysql_close($DatabaseConnection);
				}  
	  											
			 ?>
                            <p class="change_link">
                                go to administrator page ?
                                <a href="AdminPage.php" class="to_register">click here</a> </p>                        
                      </form>
              		</div>                   
       		</div>  
    	</section> 
        
</div>
</body>
</html>