
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Lead Learn</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<!-- <link rel="shortcut icon" href="favicon.ico"> -->
	
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/icomoon.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
    
    <link href="css/templatemo_style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="css/gallery_style.css" />

	<link rel="stylesheet" href="css/style.css">
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body class="boxed">

<?php
		  $NIC=$_GET['p'];
		  
		  $ServerConnection = mysql_connect('localhost','root','123456789');			
		 //check connection successful
          if(!$ServerConnection)
		  {?>
			<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
		  }
		  else
		  {
			 //connect to the data base
			 $DatabaseConnection = mysql_select_db("lldb")  ;
			 if(!$DatabaseConnection)
			 {?>
				<script type="text/javascript">alert("Could not connect to the Database")</script><?php
			 }
			else
			{
			  //search student details
		       $SearchDetails=mysql_query("SELECT * FROM ecstaff WHERE NICNumber='$NIC'");	

		       while($row=mysql_fetch_array($SearchDetails))
               {
			     
 		         $FirstNameTemp= $row[1];
			     $LastNamTemp=$row[2]; 
			     $EmailAddress= $row[6];
               }
			   $FullName= $FirstNameTemp." ".$LastNamTemp;
			   
			   
			   //search profile image
		       $SearchUrl=mysql_query("SELECT * FROM stproftbl WHERE NICNumber='$NIC'");	

		       while($row=mysql_fetch_array($SearchUrl))
               {
 		         $TempUrl= $row[1];
			   }
			  
			  
		    }
		   }
		   
		?>
	<!-- Loader -->
	<div class="fh5co-loader"></div>

	<div id="wrap">

	<div id="fh5co-page">
		<header id="fh5co-header" role="banner">
			<div class="container">
				<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i>dfd</i></a>
                <!--add a logo-->
				<div id="fh5co-logo"><a href="index.html"><img src="images/logo.jpg" alt="Free HTML5 Website Template"></a></div>
  <nav id="fh5co-main-nav" role="navigation">
					<ul>
                    <li><a href="Home.php">LogOut</a></li>
						
					</ul>
				</nav>
			</div>
		</header>
		<!-- Header -->

		<div class="fh5co-slider">
			<div class="container">
				<div class="owl-carousel owl-carousel-main">
				  <div><img src="images/1.jpg" alt="Free HTML5 Website Template"></div>
				  <div><img src="images/2.jpg" alt="Free HTML5 Website Template"></div>
				  <div><img src="images/3.jpg" alt="Free HTML5 Website Template"></div>
				</div>
			</div>
		</div>
		<!-- Slider -->
		
		<div id="fh5co-intro" class="fh5co-section">
			<div class="container">
				<div class="row row-bottom-padded-md">
					<div class="col-md-8 col-md-offset-2 text-center ts-intro">
						<h1>University of Lead Learn</h1>
                        <hr/>
						<p class="fh5co-lead">The University, established in 1904, is one of the largest higher education institutions in the UK. We are a world top 100 university and are renowned globally for the quality of our teaching and research.</p>
				  </div>
				</div>
				<div class="row row-bottom-padded-sm">
				  <div id="templatemo_content_panel_1">

	<div id="templatemo_news_section_01_01">
    	<h1 align="center">Your Profile - Coordinator</h1>

    	<form id="form2" name="form2" method="POST" action="">
    	  <table width="367" height="73" border="0">
            <tr>
              <td width="186" height="42"><div id="templatemo_content_panel_2_1">    
              <div class="templatemo_section_2"><img src="<?php echo $TempUrl ?>" width="150" height="130" alt="No uploaded Image"/></div>
              </div></td>              
              <td width="171"><font size="+0.9"><u><b><?php echo $FullName ?></b></u></font></td>
            </tr>
            <tr>
              <td width="186" height="42">              </td>              
              <td width="171"></td>
            </tr>
          </table>
      </form>
    	        
    	<div class="templatemo_news_box">
    
      
            <form id="form1" name="form1" method="post" action="">
              <table width="394" border="0" align="center">              
                <tr>
                  <td width="139">NIC Number</td>
                  <td width="245"><?php echo $NIC ?></td>
                </tr>
                <tr>
                  <td>First Name</td>
                  <td><?php echo $FirstNameTemp ?></td>
                </tr>
                <tr>
                  <td>Last Name</td>
                  <td><?php echo $LastNamTemp ?></td>
                </tr>
                <tr>
                  <td>Email Address</td>
                  <td><?php echo $EmailAddress ?></td>
                </tr>               
                <tr>
                  <td height="18"></td>
                  <td></td>
                </tr>
                 <tr>
                  <td></td>
                  <td></td>
                </tr>
                 <tr>
                  <td>Edit profile</td>
                  <td><label>
                    <input type="submit" name="button" id="button" value=" <<  Edit  >> " />
                  </label></td>
                </tr>
              </table>
        </form>
            <p>&nbsp;</p>
      </div>
    </div><!-- end of news section -->
    
    <div id="templatemo_section_1_1_5">
    <br/>
    
    	<h1 align="center">Your Opportunity </h1>
      <form method="get" action="#" id="formCenter">
        <table width="557" height="344" border="0" align="center">
           <tr>
              <td width="302">&nbsp;</td>
            <td width="175">&nbsp;</td>
          </tr>
             <tr>
              <td>View &amp; Download Upload Claim</td>
              <td><label><a href="DownloadClaim.php?p=<?php echo $NIC ?>">Click Here</a></label></td>
            </tr>
            <tr>
              <td>View Email Attachment</td>
              <td><label><a href="Uploadclaim.php?p=<?php echo $NIC ?>">Click Here</a></label></label></td>
            </tr>
            <tr>
              <td>Edit Upload Claim</td>
              <td><a href="Uploadclaim.php?p=<?php echo $NIC ?>">Click Here</a></label></label></td>
            </tr>
            <tr>
              <td height="44" colspan="2" align="center">Report View</td>
              
            </tr>
            <tr>
              <td>Number Of Claim Submission for each faculty</td>
              <td><label><a href="NumberOfClaimSubmission.php?">Click Here</a></label></td>
            </tr>
            <tr>
              <td>precentage of number of claim submission for each faculty</td>
              <td><label><a href="NumberOfClaimSubmissionPracentage.php">Click Here</a></label></label></td>
            </tr>
            <tr>
              <td>Claim Without Evidance for each faculty</td>
              <td ><label><a href="ClaimWithoutEvidance.php">Click Here</a></label></td>               
            </tr>
            <tr>
              <td>Number of student of making claim for each faculty</td>
              <td ><label><a href="NumberOfStudent.php">Click Here</a></label></td>               
            </tr>
            <tr>
              
          </table>
          
      </form>
    </div><!-- end of section 1 -->    
</div>
			  </div>
		  </div>
		</div>

		<footer id="fh5co-footer" role="contentinfo">
			<div class="container">
				<div class="row row-bottom-padded-sm">
					<div class="col-md-4 col-sm-12">
						<div class="fh5co-footer-widget">
							<h3>About Us</h3>
							<p>The University, established in 1904, is one of the largest higher education institutions in the UK. We are a world top 100 university and are renowned globally for the quality of our teaching and research..</p>
						</div>
					</div>
					<div class="col-md-3 col-md-push-1 col-sm-12 col-sm-push-0">
						<div class="fh5co-footer-widget">
							<h3>Quick Links</h3>
							<ul class="fh5co-footer-link">
								<li><a href="Home.php">Lougout</a></li>
								
							</ul>
						</div>
					</div>
					<div class="col-md-3 col-md-push-2 col-sm-12 col-sm-push-0">
						
						<div class="fh5co-footer-widget">
							<h3>Follow us</h3>
							<ul class="fh5co-social">
								<li class="facebook"><a href="#"><i class="icon-facebook2"></i></a></li>
								<li class="twitter"><a href="#"><i class="icon-twitter"></i></a></li>
								<li class="linkedin"><a href="#"><i class="icon-linkedin"></i></a></li>
								<li class="message"><a href="#"><i class="icon-mail"></i></a></li>
							</ul>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12">
						<div class="fh5co-copyright">
							<p class="pull-left">&copy; 2017 Free Template. All Rights Reserved. </p>
							<p class="pull-right">Designed by <a href="http://freehtml5.co" target="_blank">lead learn</a> web development team: <a href="http://akamilaudayanga.tk" target="_blank">We are</a></p>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-chevron-down"></i></a>
	</div>
	
	<script src="js/jquery.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>

