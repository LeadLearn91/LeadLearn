
<!DOCTYPE html>
<head>
	<meta charset="UTF-8" />
    <title>Leed Learn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
    <script src="js/LoginCheck.js" type="text/javascript"></script>
    <script type="text/javascript">
		function ValidateLoginForm()
		{
			/*Assigne input values into variable*/         
			
								
			var TempStDateValidate=document.loginFrm.StDate.value;
			var TempEndDateValidate = document.loginFrm.EndDate.value;						
			var TempECCtypeValidate=document.loginFrm.ECCtype.value;
			
              
			/*check conditions*/
			
			var numeric = /^[0-9]+$/;
            var alpha = /^[a-zA-Z]+$/;
			
            
			/*validate Customer NIC Number text field*/
			
			
			 if (TempStDateValidate.match(" "))
	        {
				
				alert("Start date out of field");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}	
				else if (TempStDateValidete.match(alpha))
	        {
				
				alert(" Incorrect Start date formate");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}	
			else if (TempStDateValidate.length>12)
	        {
				
				alert("Incorrect Start date length");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}
			else if (TempStDateValidate.length<6)
	        {
				
				alert(" Incorrect Start date length");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}
			// validate pasword text field
			
			else if (TempEndDateValidate.match(" "))
	        {
				
				alert("End date out of field");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}	
				else if (TempEndDateValidete.match(alpha))
	        {
				
				alert(" Incorrect End date formate");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}	
			else if (TempEndDateValidate.length>12)
	        {
				
				alert("Incorrect End date length");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}
			else if (TempEndDateValidate.length<6)
	        {
				
				alert(" Incorrect End date length");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.match(" "))
	        {
				
				alert("EC claim type out of fleld. Check and enter again");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.match(numeric))
	        {
				
				alert(" Incorrect EC claim type formate");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.length>=12)
	        {
				
				alert(" Incorrect EC claim type length");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.length<5)
	        {
				
				alert(" Incorrect EC claim type length");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else
			{			  
			   return true;
			}
			}
			</script>

</head>
	<body>
      <?php
        $_POST['FacultyId'] =$_GET['p'].trim();
        $_POST['CID'] =$_GET['q'].trim();
        $_POST['Name']=$_GET['r'].trim();
        $_POST['Section']=$_GET['s'].trim();
     ?>

    	<div class="container">
        <!-- Codrops top bar -->
        	<div class="codrops-top">
            	<span class="right">
                   
                </span>
            <div class="clr"></div>
            </div><!--/ Codrops top bar -->
      	<header>
        <br/>
        	<h1>Edit shedule <span> - Edit faculty Details</span></h1>
    </header>        
        <section>				
        	<div id="container_demo" >
            	<a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                	<div id="login" class="animate form">
                    	<form method="post" name="loginFrm" id="loginFrm">      
                       <h1>Faculty Details</h1> 
                       <p> 
                                <label for="SheduleId" class="uname" data-icon="S" >Faculty Id </label>
                                <input id="FacultyId" name="FacultyId" type="text" readonly="readonly" title="Cannot Edit"onBlur="checkAvailability()" value="<?php echo $_POST['FacultyId'].trim()?>"/> <span id="user-availability-status"></span>
                            </p>
                            <p> 
                                <label for="ECSID" class="uname" data-icon="u" >Faculty Coordinator Id</label>
                                <input id="ECSID" name="ECSID" type="text" readonly="readonly" onBlur="checkAvailability()" value="<?php echo $_POST['CID'].trim();?>"/> <span id="user-availability-status" ></span>
                            </p>
                            
                            <p> 
                                <label for="StDate" class="youpasswd" data-icon="p">Name</label>
                                <input id="Name" name="Name" type="text" placeholder="eg yyyy/mm/dd" value="<?php echo $_POST['Name']?>" /> 
                            </p>
                            <p> 
                                <label for="EndDate" class="youpasswd" data-icon="p">Section</label>
                                <input id="Section" name="Section" type="text" placeholder="eg yyyy/mm/dd" value="<?php echo $_POST['Section']?>" /> 
                            </p>                          
                            
                      <p class="keeplogin"> 
                                <input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
                                <label for="loginkeeping">Keep me logged in</label>
                            </p>
                            
                            <p class="login button"> 
                                <input type="submit" name="Update" value="Update"   title="Go to shedule view page"onclick="return ValidateLoginForm()" /> 
                            </p>
                            <p class="Delete button">
                              <input type="submit" name="Delete" value="Delete"   title="Go to shedule view page"onClick="return ValidateLoginForm()" />
                            </p>
                            
                           
                            <?php
					if(isset($_POST["Delete"]))
					{		  
					
		  			   $TempFacId=$_POST['FacultyId'].trim();
		               $ServerConnection = mysql_connect('localhost','root','123456789');			
		              //check connection successful
                      if(!$ServerConnection)
		              {?>
			            <script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
		              }
		              else
		              {
			            //connect to the data base
			             $DatabaseConnection = mysql_select_db("lldb")  ;
			             if(!$DatabaseConnection)
			             {?>
				           <script type="text/javascript">alert("Could not connect to the Database")</script><?php
			             }
			             else
			             {
						 ?>
					  <script type='text/javascript'> 
							       alert("Permanatly delete this record");								   						    
                                  </script>
							   <?php
			              //search student details
		                   $SearchDetailsDelete=mysql_query("DELETE * FROM faculty WHERE facultyId='$TempFacId'");	
						   
		                  }
		                }
				      }		   
		         ?> 
                 
                          <?php
     			 if (isset($_POST["Update"]))
      			 {		      		
					// initialize the variable using above insertion
				    												
					$a=$_POST['FacultyId'];
                    $b=$_POST['CID'] ;
                    $c=$_POST['Name'];
                    $d=$_POST['Section'];
					
				   //$PassStudentNICNo1=base64_encode($PassStudentLoginNICNumber);													
					//connect to the database
					$ServerConnection = mysql_connect('localhost','root','123456789');			
			  		//check connection successful
               		if(!$ServerConnection)
					{?>
						<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
					}
					else
					{
					  //connect to the data base
					  $DatabaseConnection = mysql_select_db("lldb")  ;
					  if(!$DatabaseConnection)
					  {?>
						<script type="text/javascript">alert("Could not connect to the Database")</script><?php
					  }
					  else
					  {
					  ?>
					  <script type='text/javascript'> 
							       alert("Permanatly update this record");								   						    
                                  </script>
							   <?php
					    $Update1= mysql_query("UPDATE faculty SET  facultyId='$a',ACYId='$b' ,Name='$c',Section='$d' WHERE  facultyId='$a'd");						
          			 }															
				   }
														//close the opend database 
														//mysql_close($DatabaseConnection);
				}  
				
				
				
				
				
				
	  											
			 ?>
                            <p class="change_link">
                                go to administrator page ?
                                <a href="AdminPage.php" class="to_register">click here</a> </p>                        
                      </form>
              		</div>                   
       		</div>  
    	</section> 
        
</div>
</body>
</html>