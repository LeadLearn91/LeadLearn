
<!DOCTYPE html>
<head>
	<meta charset="UTF-8" />
    <title>Login and Registration PHP - MySQL SESSION based</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" href="css/UserReg.css"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
    <script src="js/LoginCheck.js" type="text/javascript"></script>

</head>
	<body>
    	<div class="container">
        <!-- Codrops top bar -->
        	<div class="codrops-top">
            	<span class="right">
                   
                </span>
            <div class="clr"></div>
            </div><!--/ Codrops top bar -->
      	<header>
        	<h1>Login and Registration <span> - WECARE system</span></h1>
    </header>
        
        <section>				
        	<div id="container_demo" >
            	<a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                	<div id="login" class="animate form">
                    	<form  action="login.php" autocomplete="on" method="post">      
                       <h1>Log in</h1> 
                       <p> 
                                <label for="usertype" class="uname" > User Type<br /></label>
                                <select   name="gender" class="shortenedSelect">
    		                     <option value="Male">Administrator</option>
    		                     <option value="Femail">EC Manager</option>
                                 <option value="Femail">EC Coordinator</option>
    	                         </select> 
                          </p>
                            
                            <p> 
                                <label for="username" class="uname" data-icon="u" > Your username </label>
                                <input id="username" name="username" required="required" type="text" placeholder="myusername" onBlur="checkAvailability()"/> <span id="user-availability-status"></span>
                            </p>
                            
                            <p> 
                                <label for="password" class="youpasswd" data-icon="p"> Your password </label>
                                <input id="password" name="password" required="required" type="password" placeholder="eg. X8df!90EO" /> 
                            </p>
                            
                            <p class="keeplogin"> 
                                <input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
                                <label for="loginkeeping">Keep me logged in</label>
                            </p>
                            
                            <p class="login button"> 
                                <input type="submit" name="login" value="Login" /> 
                            </p>
                            
                            <p class="change_link">
                                Not a member yet ?
                                <a href="UserRegistration.php" class="to_register">REGISTER - Sign Up</a>
                                
                            </p>                        
                        </form>
              		</div>                   
       		</div>  
    	</section> 
</div>
</body>
</html>