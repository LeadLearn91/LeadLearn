
<!DOCTYPE html>
<head>
	<meta charset="UTF-8" />
    <title>Leed Learn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
    <script src="js/LoginCheck.js" type="text/javascript"></script>
    <script type="text/javascript">
		function ValidateLoginForm()
		{
			/*Assigne input values into variable*/
            
			var TempSheduleIdValidete = document.loginFrm.SheduleId.value;
			var TempECSIDValidate = document.loginFrm.ECSID.value;						
			var TempStDateValidate=document.loginFrm.StDate.value;
			var TempEndDateValidate = document.loginFrm.EndDate.value;						
			var TempECCtypeValidate=document.loginFrm.ECCtype.value;
			
              
			/*check conditions*/
			
			var numeric = /^[0-9]+$/;
            var alpha = /^[a-zA-Z]+$/;
			
            
			/*validate Customer NIC Number text field*/
			if (TempSheduleIdValidete.match(" "))
	        {
				
				alert("Shedule Id out of fleld. Check and enter again");
			    document.getElementById("SheduleId").style.backgroundColor = '#f44336';
			    document.getElementById("SheduleId").style.color = 'black';			
				document.getElementById("SheduleId").value = "";				
			    document.getElementById("SheduleId").focus();			  
			    return false;
			}
			else if (TempSheduleIdValidete.match(numeric))
	        {
				
				alert(" Incorrect Shedule Id formate");
			    document.getElementById("SheduleId").style.backgroundColor = '#f44336';
			    document.getElementById("SheduleId").style.color = 'black';			
				document.getElementById("SheduleId").value = "";				
			    document.getElementById("SheduleId").focus();			  
			    return false;
			}
			else if (TempSheduleIdValidete.length>=12)
	        {
				
				alert(" Incorrect Shedule Id  length");
			    document.getElementById("SheduleId").style.backgroundColor = '#f44336';
			    document.getElementById("SheduleId").style.color = 'black';			
				document.getElementById("SheduleId").value = "";				
			    document.getElementById("SheduleId").focus();			  
			    return false;
			}
			else if (TempSheduleIdValidete.length<5)
	        {
				
				alert(" Incorrect Shedule Id length");
			    document.getElementById("SheduleId").style.backgroundColor = '#f44336';
			    document.getElementById("SheduleId").style.color = 'black';			
				document.getElementById("SheduleId").value = "";				
			    document.getElementById("SheduleId").focus();			  
			    return false;
			}
			
			 //check user name text field
			
			else if (TempECSIDValidate.match(" "))
	        {
				
				alert("EC Claim Id out of field");
			    document.getElementById("ECSID").style.backgroundColor = '#f44336';
			    document.getElementById("ECSID").style.color = 'black';			
				document.getElementById("ECSID").value = "";				
			    document.getElementById("ECSID").focus();			  
			    return false;
			}
			else if (TempECSIDValidete.match(numeric))
	        {
				
				alert(" Incorrect EC Claim Id formate");
			    document.getElementById("ECSID").style.backgroundColor = '#f44336';
			    document.getElementById("ECSID").style.color = 'black';			
				document.getElementById("ECSID").value = "";				
			    document.getElementById("ECSID").focus();			  
			    return false;
			}		
			else if (TempECSIDValidate.length>12)
	        {
				
				alert("IncorrectEC Claim Id length");
			    document.getElementById("ECSID").style.backgroundColor = '#f44336';
			    document.getElementById("ECSID").style.color = 'black';			
				document.getElementById("ECSID").value = "";				
			    document.getElementById("ECSID").focus();			  
			    return false;
			}
			else if (TempECSIDValidate.length<5)
	        {				
				alert(" Incorrect EC Claim Id length");
			    document.getElementById("ECSID").style.backgroundColor = '#f44336';
			    document.getElementById("ECSID").style.color = 'black';			
				document.getElementById("ECSID").value = "";				
			    document.getElementById("ECSID").focus();			  
			    return false;
			}
			
			// validate pasword text field
			
			else if (TempStDateValidate.match(" "))
	        {
				
				alert("Start date out of field");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}	
				else if (TempStDateValidete.match(alpha))
	        {
				
				alert(" Incorrect Start date formate");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}	
			else if (TempStDateValidate.length>12)
	        {
				
				alert("Incorrect Start date length");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}
			else if (TempStDateValidate.length<6)
	        {
				
				alert(" Incorrect Start date length");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}
			// validate pasword text field
			
			else if (TempEndDateValidate.match(" "))
	        {
				
				alert("End date out of field");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}	
				else if (TempEndDateValidete.match(alpha))
	        {
				
				alert(" Incorrect End date formate");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}	
			else if (TempEndDateValidate.length>12)
	        {
				
				alert("Incorrect End date length");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}
			else if (TempEndDateValidate.length<6)
	        {
				
				alert(" Incorrect End date length");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.match(" "))
	        {
				
				alert("EC claim type out of fleld. Check and enter again");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.match(numeric))
	        {
				
				alert(" Incorrect EC claim type formate");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.length>=12)
	        {
				
				alert(" Incorrect EC claim type length");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.length<5)
	        {
				
				alert(" Incorrect EC claim type length");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else
			{			  
			   return true;
			}
			}
			</script>

</head>
	<body>
    	<div class="container">
        <!-- Codrops top bar -->
        	<div class="codrops-top">
            	<span class="right">
                   
                </span>
            <div class="clr"></div>
            </div><!--/ Codrops top bar -->
      	<header>
        <br/>
        	<h1>Create shedule <span> - CLAIM Submission</span></h1>
    </header>
        
        <section>				
        	<div id="container_demo" >
            	<a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                	<div id="login" class="animate form">
                    	<form method="post" name="loginFrm" id="loginFrm">      
                       <h1>Shedule</h1> 
                       <p> 
                                <label for="SheduleId" class="uname" data-icon="S" >Sedule Id </label>
                                <input id="SheduleId" name="SheduleId" type="text" placeholder="Shedule Id" onBlur="checkAvailability()" value="<?php echo $_POST['SheduleId']?>"/> <span id="user-availability-status"></span>
                            </p>
                            <p> 
                                <label for="ECSID" class="uname" data-icon="u" > Claim Subbmission Id</label>
                                <input id="ECSID" name="ECSID" type="text" placeholder="ClaimId" onBlur="checkAvailability()" value="<?php echo $_POST['ECSID']?>"/> <span id="user-availability-status" ></span>
                            </p>
                            
                            <p> 
                                <label for="StDate" class="youpasswd" data-icon="p"> Start Date</label>
                                <input id="StDate" name="StDate" type="text" placeholder="eg yyyy/mm/dd" value="<?php echo $_POST['StDate']?>" /> 
                            </p>
                            <p> 
                                <label for="EndDate" class="youpasswd" data-icon="p"> End Date</label>
                                <input id="EndDate" name="EndDate" type="text" placeholder="eg yyyy/mm/dd" value="<?php echo $_POST['EndDate']?>" /> 
                            </p>
                            
                            <p> 
                                <label for="ECCtype" class="youpasswd" data-icon="p">Claim type</label>
                                <input id="ECCtype" name="ECCtype" type="text" placeholder="Claim Type" value="<?php echo $_POST['ECCtype']?>" /> 
                            </p>
                      <p class="keeplogin"> 
                                <input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
                                <label for="loginkeeping">Keep me logged in</label>
                            </p>
                            
                            <p class="login button"> 
                                <input type="submit" name="login" value="Login"  onclick="return ValidateLoginForm()" /> 
                            </p>
                            <?php
     			 if (isset($_POST["login"]))
      			 {		      		
					// initialize the variable using above insertion
				    												
					$TempSheduleId=$_POST['SheduleId'];
					$TempECSID=$_POST['ECSID'];
					$TempStDate=$_POST['StDate'];
					$TempEndDate=$_POST['EndDate'];
					$TempECCtype=$_POST['ECCtype'];
					$currents='Available';
					
				
					//$PassStudentNICNo1=base64_encode($PassStudentLoginNICNumber);													
					//connect to the database
					$ServerConnection = mysql_connect('localhost','root','123456789');			
			  		//check connection successful
               		if(!$ServerConnection)
					{?>
						<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
					}
					else
					{
					  //connect to the data base
					  $DatabaseConnection = mysql_select_db("lldb")  ;
					  if(!$DatabaseConnection)
					  {?>
						<script type="text/javascript">alert("Could not connect to the Database")</script><?php
					  }
					  else
					  {
					    $InsertCustomerDetails=mysql_query("insert into shedule  values('$TempSheduleId','$TempECSID','$TempStDate','$TempEndDate','$currents','$TempECCtype')");
						 if(!$InsertCustomerDetails)
						 {?>
							 <script type="text/javascript">
							  alert("this shedule alredy existing. Enter correct shedule")
							  document.getElementById("SheduleId").style.backgroundColor = '#00E676';
			    			  document.getElementById("SheduleId").style.color = 'black';			
							  document.getElementById("SheduleId").value = "";				
			    			  document.getElementById("SheduleId").focus();
                             </script><?php
						  }
						  else
						 {?>
						   <script type="text/javascript">alert("Your registration Successful, Now you are a member here")</script><?php
							// insert data into login table
							$type='Student';
							 $InsertCustomerDetails=mysql_query("insert into logintbl values('$PassStdNicNumber','$PassUserName','$PassPassword','$type')");
							 
							  echo'<META HTTP-EQUIV="Refresh" Content="0;URL=AddAsignmentItem.php?p='.$TempECSID.'">';
															
						}
          			 }															
				   }
														//close the opend database 
														//mysql_close($DatabaseConnection);
				}  
	  											
			 ?>
                            <p class="change_link">
                                go to administrator page ?
                                <a href="AdminPage.php" class="to_register">click here</a> </p>                        
                      </form>
              		</div>                   
       		</div>  
    	</section> 
        
</div>
</body>
</html>