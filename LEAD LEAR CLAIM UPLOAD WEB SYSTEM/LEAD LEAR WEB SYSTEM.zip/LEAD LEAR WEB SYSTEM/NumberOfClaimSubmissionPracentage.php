<!DOCTYPE>
<html>
<head>
<title>LEAD LEARN</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/book.css" />
    <link href="css/font-awesome.min.css" rel="stylesheet">  
    <link rel="stylesheet" type="text/css" href="css/bg_hospital_infor.css" /> 
<style>
table {
    border-collapse: collapse;
}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

tr:nth-child(even){background-color: #FFF }

th {
    background-color:#F60;
    color: white;
	text-align:center;	
}

h1 {
	color: #333333;
    font-family: 'Roboto Condensed',sans-serif;
		color: #fff;
    font-size: 42px;
    font-weight: 700;
	text-shadow: 0 1px 5px #222222;
	text-align:center;
}

#book-can {
background-color:#F90;
margin-top:20px;
margin-left:45%;
}
img {
margin-left:35%;
}
.bbtn-dialog{
width:100px;
background:#FFFF33;
}
.percentageFill{
margin-left:400px;
width:500px;
    height:30px;

    background: -webkit-linear-gradient(left, red 37.50%,#ffffff 75%);
    background:    -moz-linear-gradient(left, red 37.50%, #ffffff 75%);
    background:     -ms-linear-gradient(left, red 37.50%,#ffffff 75%);
    background:      -o-linear-gradient(left, red 37.50%,#ffffff 75%);
    background:         linear-gradient(to right, red 37.50%,#ffffff 75%);

    border:1px solid black;
}
.percentageFill1{
margin-left:400px;
width:500px;
    height:30px;

    background: -webkit-linear-gradient(left, blue 37.50%,#ffffff 75%);
    background:    -moz-linear-gradient(left, blue 37.50%, #ffffff 75%);
    background:     -ms-linear-gradient(left, blue 37.50%,#ffffff 75%);
    background:      -o-linear-gradient(left, blue 37.50%,#ffffff 75%);
    background:         linear-gradient(to right, blue 37.50%,#ffffff 75%);

    border:1px solid black;
}
</style>
</head>
<body>
<p></p>
       <h1>NUMBER OF CLAIMS WITHIN EACH FACULTY FOR EACH ACEDAMIC YEAR</h1>
       <p><img src="images/1.jpg" height='142' width='418' /></p>
       <p>&nbsp;       </p>
<form>
<table border="1" align="center">

  <tr>
                <th style='width:300px;'>Faculty name</th>
                <th style='width:150px;'>Section</th>
				<th style='width:150px;'>Start Date</th>
				<th style='width:150px;'>End Dte</th>
                
                <th style='width:70px;'>ecc id</th>
               
               
                
                
				
                																	
			</tr>
            
  <p>

    <?php
			
     			
				 
	              //connect to the database
				  $ServerConnection = mysql_connect('localhost','root','123456789');			
			  	 //check connection successful
               	  if(!$ServerConnection)
				  {?>
    <script type="text/javascript">alert("Could not connect to the Localhost server")</script>
    
    <?php
				  }
				  else
				 {
				   //connect to the data base
					$DatabaseConnection = mysql_select_db("lldb")  ;
					if(!$DatabaseConnection)
					{?>
    <script type="text/javascript">alert("Could not connect to the Database")</script>
    <?php
					}
					else
					{	
						 
						 $SearchStDetails=mysql_query("SELECT (count(ecc.EC_ClaimId)/8)*100 AS y, f.Name,f.Section , ac.StartDate, ac.EndDate  from ecclaim ecc , faculty f , academicyear ac where ecc.FacultyId=f.facultyId and f.ACYId=ac.ACYId group by f.Name ");
						  while($RawStDetails=mysql_fetch_array($SearchStDetails))
		  			      {
						 
						  
				
				
		      			     echo "<tr>";
							 echo "<td>" . $RawStDetails['Name'] . "</td>";
							 echo "<td>" . $RawStDetails['Section'] . "</td>";
                             echo "<td>" . $RawStDetails['StartDate'] . "</td>";
				             echo "<td>" . $RawStDetails['EndDate'] . "</td>";
				
				             echo "<td>" . $RawStDetails['y'].' % '. "</td>";
				
                
               // echo "<td>" . $RawStDetails['StartDate'] . "</td>";
               // echo "<td>" . $RawStDetails['EndDate'] . "</td>";
               // echo "<td>" . $RawStDetails['CurrentStatues'] . "</td>";
				//echo "<td>" . $RawStDetails['SType'] . "</td>";
                //echo "<td> <a href ='EditShedule.php?p= $x & k=$y & q=$z & r=$a' & s=$b & t=$c><button type='button' id='book-can name ='book-can. onClick='GotoHome1()' class='bbtn-dialog'><i class='fa fa-check-square-o fa-fw'></i> Edit</button></a></td>";	
				
							
		 			   echo "</tr>";   }
					  echo " </table>";
		  	
                     	
					}
                      
		          }
			
                ?>  
    
  </p>
<br/>
<div class='percentageFill'> Faculty of Computer Science -: 37.50%</div>
<br/>
<div class='percentageFill1'> Software Engineering -: 37.50%</div>


</body>
</html>