// JavaScript Document
function checkAvailability() {
	$("#loaderIcon").show();
	jQuery.ajax({
	url: "Logon_check_availability_UserName.php",
	data:'username='+$("#username").val(),
	type: "POST",
	success:function(data){
		$("#user-availability-status").html(data);

},
	error:function (){}
	});
}


