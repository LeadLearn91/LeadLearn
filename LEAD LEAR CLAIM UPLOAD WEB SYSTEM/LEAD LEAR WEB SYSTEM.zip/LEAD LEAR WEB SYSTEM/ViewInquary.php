
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Lead Learn</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<!-- <link rel="shortcut icon" href="favicon.ico"> -->
	
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/icomoon.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<link rel="stylesheet" href="css/style.css">
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	</head>
	<body class="boxed">
	<!-- Loader -->
	<div class="fh5co-loader"></div>

	<div id="wrap">

	<div id="fh5co-page">
		<header id="fh5co-header" role="banner">
			<div class="container">
				<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
				<div id="fh5co-logo"><a href="index.html"><img src="images/logo.jpg" alt="Free HTML5 Website Template"></a></div>
				<nav id="fh5co-main-nav" role="navigation">
					<ul>
                    <li><a href="Student.php">porfile</a></li>
						<li><a href="Home.php">Logout</a></li>						
						
					</ul>

				</nav>
			</div>
		</header>
		<!-- Header -->

		<div id="fh5co-intro" class="fh5co-section">
			<div class="container">
				<div class="row row-bottom-padded-sm">
					<div class="col-md-8 col-md-offset-2 text-center ts-intro">
						<h1>University of Lead Learn</h1>
				
		<p class="fh5co-lead">The University, established in 1904, is one of the largest higher education institutions in the UK. We are a world top 100 university and are renowned globally for the quality of our teaching and research.</p>
					</div>
				</div>
				<div class="row row-bottom-padded-sm">
					<div class="col-md-8 col-md-push-4" id="fh5co-content">
						<h2>About Claim submition </h2>
						<p>As a Student Health Plan (SHP) member, when you receive care at Gannett Health Services or another  Aetna-participating provider, any claims that need to be submitted for reimbursement will be submitted directly to Aetna for you.</p>

                        <p>When a claim is submitted on your behalf, you will receive and Explanation of Benefits (EOB) in the mail after your visit that explains what your provider charged and what was covered under SHP. If you have any questions about your EOB, please contact the office of Student Health Benefits.</p>
						 <h3>Using the website you can:</h3>
                 <ul>
                   <li> Submit your health claims for yourself and other members of your family who are covered by your plan.</li>
                   <li>Check the progress of claims</li>
                   <li>Access your insurance plan information</li>
                   <li>View and update your details</li>
                 <ul> 
                 <br/>
    <h3>Special Note:</h3>

                <p><strong>If you wish to claim for several treatments for the same condition and the same claimant , there is no need to enter the whole claim for each treatment you can simply add additional treatments to the same claim by choosing the add treatment option.</strong></p>
                <p><strong> Once you have entered all of the treatment information you will need to upload scanned copies of your receipts to support the claim for that treatment. In order to upload the copies of your receipts click on the + next to the treatment entry. Next click on ‘Add files’ and find the scanned copy of your document, then click ‘Upload’ and wait for the document to arrive in the treatment box. You may add here as many documents as you have for your claim submission. Clicking on the Bin will remove the document.</strong></p>
                
	</div>
    
					
                    
                    <div class="col-md-4 col-md-pull-8" id="fh5co-sidebar">
                    <?php
		  $NIC=$_GET['p'];
		  
		  $ServerConnection = mysql_connect('localhost','root','123456789');			
		 //check connection successful
          if(!$ServerConnection)
		  {?>
			<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
		  }
		  else
		  {
			 //connect to the data base
			 $DatabaseConnection = mysql_select_db("lldb")  ;
			 if(!$DatabaseConnection)
			 {?>
				<script type="text/javascript">alert("Could not connect to the Database")</script><?php
			 }
			else
			{
			  //search student details
		       $SearchDetails=mysql_query("SELECT * FROM student WHERE NICNumber='$NIC'");	

		       while($row=mysql_fetch_array($SearchDetails))
               {
			     $FacIdTemp= $row[1];
 		         $FirstNameTemp= $row[2];
			     $LastNamTemp=$row[3]; 
			     $EmailAddress= $row[7];
               }
			   $FullName= $FirstNameTemp." ".$LastNamTemp;
			   //search faculty details
		       
			   
			   //search profile image
		       $SearchUrl=mysql_query("SELECT * FROM stproftbl WHERE NICNumber='$NIC'");	

		       while($row=mysql_fetch_array($SearchUrl))
               {
 		         $TempUrl= $row[1];
			   }
			  
			   $SearchFacultyDetails=mysql_query("SELECT * FROM  faculty WHERE facultyId='$FacIdTemp'");
			   
			  while($row=mysql_fetch_array($SearchFacultyDetails))
               {
 		         $FacName= $row[2];
				 $FacSection= $row[3];
			   }
			  
		    }
		   }
		   
		?>
						<div class="fh5co-service text-left">
							<img src="<?php echo $TempUrl ?>" class="img-responsive img-bordered" alt="Free HTML5 Bootstrap Template by FreeHTML5.co">
                            
							<h3><?php echo $FullName ?></h3>
                            <br/>
							<p>Faculty Name -: <?php echo $FacName ?></p>
                            <p>Faculty Name -: <?php echo $FacSection ?></p>
							
						</div>
						
					</div>
				</div>
				

			</div>
		
<div class="row row-bottom-padded-md">
					<div class="col-md-8 col-md-offset-2 text-center ts-intro">
						<h1>Claim Submition format</h1>						
					</div>
				</div>
				<div class="row row-bottom-padded-sm">
					<div class="col-md-4">
						<div class="fh5co-service text-center"><img src="images/cl1.jpg" class="img-responsive img-bordered" alt="Lead Learn University Student"></div>
				  </div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<img src="images/cl2.jpg" class="img-responsive img-bordered" alt="Lead Learn University Student">
							
						</div>
					</div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<a href="http://www.etsu.edu/nursing/shserv/pictures/Patient%20Information%20Form.jpg"><img src="images/cl3.jpg" class="img-responsive img-bordered" alt="Lead Learn University Student"></a>
						</div>
					</div>

					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<a href="http://punchlisttemplate.co/wp-content/uploads/2016/06/health-history-template-121094110.png"><img src="images/cl4.jpg" class="img-responsive img-bordered" alt="Lead Learn University Student"></a>
						</div>
					</div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<a href="http://www.toltecsd.org/Downloads/2014%20Toltec%20Med%20Emergency%20ENG%20001.jpg"><img src="images/cl5.jpg" class="img-responsive img-bordered" alt="Lead Learn University Student"></a>
						</div>
					</div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<a href="https://s-media-cache-ak0.pinimg.com/736x/b3/1b/88/b31b880b616cf77b7c99283165284323.jpg"><img src="images/cl6.jpg" class="img-responsive img-bordered" alt="Lead Learn University Student"></a>
						</div>
					</div>

					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<a href="https://s-media-cache-ak0.pinimg.com/736x/ef/0e/cc/ef0ecc0ab868ad874549b0f9c6090bd2.jpg"><img src="images/cl7.jpg" class="img-responsive img-bordered" alt="Lead Learn University Student"></a>
						</div>
					</div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<a href="https://www.yumpu.com/en/image/facebook/31211962.jpg"><img src="images/cl8.jpg" class="img-responsive img-bordered" alt="Lead Learn University Student"></a>
						</div>
					</div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<img src="images/slider_3.jpg" class="img-responsive img-bordered" alt="Lead Learn University Student">
						</div>
					</div>
                    </div>
			</div>
		<footer id="fh5co-footer" role="contentinfo">
			<div class="container">
				<div class="row row-bottom-padded-sm">
					<div class="col-md-4 col-sm-12">
						<div class="fh5co-footer-widget">
							<h3>About Us</h3>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum fuga rerum doloremque dolore, molestias eligendi. Nulla aliquam aut doloribus tenetur repellendus omnis dicta, unde magni.</p>
						</div>
					</div>
					<div class="col-md-3 col-md-push-1 col-sm-12 col-sm-push-0">
						<div class="fh5co-footer-widget">
							<h3>Quick Links</h3>
							<ul class="fh5co-footer-link">
								<li><a href="StudentPage.php">Profile</a></li>
								<li><a href="Home.php">Logout</a></li>
								
							</ul>
						</div>
					</div>
					<div class="col-md-3 col-md-push-2 col-sm-12 col-sm-push-0">
						
						<div class="fh5co-footer-widget">
							<h3>Follow us</h3>
							<ul class="fh5co-social">
								<li class="facebook"><a href="#"><i class="icon-facebook2"></i></a></li>
								<li class="twitter"><a href="#"><i class="icon-twitter"></i></a></li>
								<li class="linkedin"><a href="#"><i class="icon-linkedin"></i></a></li>
								<li class="message"><a href="#"><i class="icon-mail"></i></a></li>
							</ul>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12">
						<div class="fh5co-copyright">
							<p class="pull-left">&copy; 2017 Free Template. All Rights Reserved. </p>
							<p class="pull-right">Designed by <a href="http://freehtml5.co" target="_blank">lead learn</a> web development team: <a href="http://akamilaudayanga.tk" target="_blank">We are</a></p>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>
	</div>

<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-chevron-down"></i></a>
	</div>
	
	<script src="js/jquery.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>

