
<!DOCTYPE html>
<head>
	<meta charset="UTF-8" />
    <title>Leed Learn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
    <script src="js/LoginCheck.js" type="text/javascript"></script>
    <script type="text/javascript">
		function ValidateLoginForm()
		{
			/*Assigne input values into variable*/
            
			var TempNICNumberValidete = document.loginFrm.NICNo.value;
			var TempUserNameValidate = document.loginFrm.username.value;						
			var TempPasswordValidate=document.loginFrm.password.value;
			
              
			/*check conditions*/
			
			var numeric = /^[0-9]+$/;
            var alpha = /^[a-zA-Z]+$/;
			
            
			/*validate Customer NIC Number text field*/
			if (TempNICNumberValidete.match(" "))
	        {
				
				alert(" Incorrect Your Registration number. Check and enter again");
			    document.getElementById("NICNo").style.backgroundColor = '#f44336';
			    document.getElementById("NICNo").style.color = 'black';			
				document.getElementById("NICNo").value = "";				
			    document.getElementById("NICNo").focus();			  
			    return false;
			}
			else if (TempNICNumberValidete.match(numeric))
	        {
				
				alert(" Incorrect Your Registration number formate");
			    document.getElementById("NICNo").style.backgroundColor = '#f44336';
			    document.getElementById("NICNo").style.color = 'black';			
				document.getElementById("NICNo").value = "";				
			    document.getElementById("NICNo").focus();			  
			    return false;
			}
			else if (TempNICNumberValidete.length>=12)
	        {
				
				alert(" Incorrect Your Registration number");
			    document.getElementById("NICNo").style.backgroundColor = '#f44336';
			    document.getElementById("NICNo").style.color = 'black';			
				document.getElementById("NICNo").value = "";				
			    document.getElementById("NICNo").focus();			  
			    return false;
			}
			else if (TempNICNumberValidete.length<5)
	        {
				
				alert(" Incorrect Your Registration number");
			    document.getElementById("NICNo").style.backgroundColor = '#f44336';
			    document.getElementById("NICNo").style.color = 'black';			
				document.getElementById("NICNo").value = "";				
			    document.getElementById("NICNo").focus();			  
			    return false;
			}
			
			 //check user name text field
			
			else if (TempUserNameValidate.match(" "))
	        {
				
				alert("User Name out of field");
			    document.getElementById("username").style.backgroundColor = '#f44336';
			    document.getElementById("username").style.color = 'black';			
				document.getElementById("username").value = "";				
			    document.getElementById("username").focus();			  
			    return false;
			}		
			else if (TempUserNameValidate.length>20)
	        {
				
				alert("Incorrect user name length");
			    document.getElementById("username").style.backgroundColor = '#f44336';
			    document.getElementById("username").style.color = 'black';			
				document.getElementById("username").value = "";				
			    document.getElementById("username").focus();			  
			    return false;
			}
			else if (TempUserNameValidate.length<6)
	        {				
				alert(" Incorrect User name length");
			    document.getElementById("username").style.backgroundColor = '#f44336';
			    document.getElementById("username").style.color = 'black';			
				document.getElementById("username").value = "";				
			    document.getElementById("username").focus();			  
			    return false;
			}
			
			// validate pasword text field
			
			else if (TempPasswordValidate.match(" "))
	        {
				
				alert("Password out of field");
			    document.getElementById("password").style.backgroundColor = '#f44336';
			    document.getElementById("password").style.color = 'black';			
				document.getElementById("password").value = "";				
			    document.getElementById("password").focus();			  
			    return false;
			}		
			else if (TempPasswordValidate.length>20)
	        {
				
				alert("Incorrect Password length");
			    document.getElementById("password").style.backgroundColor = '#f44336';
			    document.getElementById("password").style.color = 'black';			
				document.getElementById("password").value = "";				
			    document.getElementById("password").focus();			  
			    return false;
			}
			else if (TempPasswordValidate.length<6)
	        {
				
				alert(" Incorrect Password length");
			    document.getElementById("password").style.backgroundColor = '#f44336';
			    document.getElementById("password").style.color = 'black';			
				document.getElementById("password").value = "";				
			    document.getElementById("password").focus();			  
			    return false;
			}
			else
			{			  
			   return true;
			}
			}
			</script>

</head>
	<body>
    	<div class="container">
        <!-- Codrops top bar -->
        	<div class="codrops-top">
            	<span class="right">
                   
                </span>
            <div class="clr"></div>
            </div><!--/ Codrops top bar -->
      	<header>
        <br/>
        	<h1>Login and Registration <span> - CLAIM Submission</span></h1>
    </header>
        
        <section>				
        	<div id="container_demo" >
            	<a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                	<div id="login" class="animate form">
                    	<form method="post" name="loginFrm" id="loginFrm">      
                       <h1>Log in</h1> 
                       <p> 
                                <label for="NICNo" class="uname" data-icon="N" > Registration Id</label>
                                <input id="NICNo" name="NICNo" type="text" placeholder="Registration Id" onBlur="checkAvailability()" value="<?php echo $_POST['NICNo']?>"/> <span id="user-availability-status"></span>
                            </p>
                            <p> 
                                <label for="username" class="uname" data-icon="u" > Your Username </label>
                                <input id="username" name="username" type="text" placeholder="myusername" onBlur="checkAvailability()" value="<?php echo $_POST['username']?>"/> <span id="user-availability-status" ></span>
                            </p>
                            
                            <p> 
                                <label for="password" class="youpasswd" data-icon="p"> Your Password </label>
                                <input id="password" name="password" type="password" placeholder="eg. X8df!90EO" value="<?php echo $_POST['password']?>" /> 
                            </p>
                            
                            <p class="keeplogin"> 
                                <input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
                                <label for="loginkeeping">Keep me logged in</label>
                            </p>
                            
                            <p class="login button"> 
                                <input type="submit" name="login" value="Login"  onclick="return ValidateLoginForm()" /> 
                            </p>
                            <?php
     			 if (isset($_POST["login"]))
      			 {		      		
					// initialize the variable using above insertion
				    												
					$TempNICNumber=$_POST['NICNo'];
					$TempUserName=$_POST['username'];
					$TempPassword=$_POST['password'];
					//$PassStudentNICNo1=base64_encode($PassStudentLoginNICNumber);													
					//connect to the database
					$ServerConnection = mysql_connect('localhost','root','123456789');			
			  		//check connection successful
               		if(!$ServerConnection)
					{?>
						<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
					}
					else
					{
					  //connect to the data base
					  $DatabaseConnection = mysql_select_db("lldb")  ;
					  if(!$DatabaseConnection)
					  {?>
						<script type="text/javascript">alert("Could not connect to the Database")</script><?php
					  }
					  else
					  {
					    // search student login details according to nic number															
					    $SeachData=mysql_query("SELECT * FROM  administratortbl WHERE AdminId='$TempNICNumber'");
						$SeachData1=mysql_query("SELECT * FROM eccoordinatortbl WHERE ECCId='$TempNICNumber'");
						$SeachData2=mysql_query("SELECT * FROM  ecmanagertbl WHERE ECMId='$TempNICNumber'");
						
						$StudentCountrows = mysql_num_rows($SeachData);
						$StudentCountrows1 = mysql_num_rows($SeachData1);
						$StudentCountrows2 = mysql_num_rows($SeachData2);
						
						// check all Existent in database									
						 if($StudentCountrows==1)
						 {
						    $SearchLogin=mysql_query("SELECT * FROM administratortbl WHERE AdminId='$TempNICNumber'");
							while($row=mysql_fetch_array($SearchLogin))
                              {
 		                          $TempNICNo= $row['NICNumber'];				  
								  
                               }
							   
							   $SearchLogin=mysql_query("SELECT * FROM logintbl WHERE NICNumber='$TempNICNo'");
							   
							   while($row=mysql_fetch_array($SearchLogin))
                              {
 		                          $UserNameTemp= $row['UserName'];	
								  $PasswordTemp= $row['Password'];			  
								  
                               }
							   
							   
							   if($UserNameTemp==$TempUserName)
							   {							   		
							         if($PasswordTemp==$TempPassword)
							         {	
								   							   		
							                echo'<META HTTP-EQUIV="Refresh" Content="0;URL=AdminPage.php?p='.$TempNICNo.'">';									
							         }
							         else
							         {
							            ?>
							              <script type='text/javascript'> 
							              alert("Not Valide Password, Check it");
								          document.getElementById("password").style.backgroundColor = '#f44336';
			                              document.getElementById("password").style.color = 'black';
			                              document.getElementById("password").focus();							    
                                          </script>
							            <?php
							          }
							   }
							   else
							   {
							    ?>
							      <script type='text/javascript'> 
							        alert("Sorry, Not Valide user name, Check it");
								    document.getElementById("username").style.backgroundColor = '#f44336';
			                        document.getElementById("username").style.color = 'black';
			                        document.getElementById("username").focus();							    
                                  </script>
							     <?php
							   }		  
		
						 }
						 elseif($StudentCountrows2==1)
						 {
						    $SearchLogin2=mysql_query("SELECT * FROM ecmanagertbl WHERE ECMId ='$TempNICNumber'");
							while($row=mysql_fetch_array($SearchLogin2))
                              {
 		                          $TempNICNo2= $row['NICNumber'];				  
								  
                               }
							   
							   $SearchLogin=mysql_query("SELECT * FROM logintbl WHERE NICNumber='$TempNICNo2'");
							   
							   while($row=mysql_fetch_array($SearchLogin))
                              {
 		                                                  $UserNameTemp= $row['UserName'];	
								  $PasswordTemp= $row['Password'];			  
								  
                               }
							   
							   
							   if($UserNameTemp==$TempUserName)
							   {							   		
							     if($PasswordTemp==$TempPassword)
							     {	
								   							   		
							                echo'<META HTTP-EQUIV="Refresh" Content="0;URL=ManagerPage.php?p='.$TempNICNo2.'">';									
							     }
							    else
							    {
							     ?>
							      <script type='text/javascript'> 
							       alert("Not Valide Password, Check it");
								   document.getElementById("password").style.backgroundColor = '#f44336';
			                       document.getElementById("password").style.color = 'black';
			                       document.getElementById("password").focus();							    
                                  </script>
							     <?php
							    }
							   }
							   else
							   {
							    ?>
							      <script type='text/javascript'> 
							        alert("Sorry, Not Valide user name, Check it");
								    document.getElementById("username").style.backgroundColor = '#f44336';
			                        document.getElementById("username").style.color = 'black';
			                        document.getElementById("username").focus();							    
                                  </script>
							     <?php
							   }		  
		
						 }
						 elseif($StudentCountrows1==1)
						 {
						    $SearchLogin1=mysql_query("SELECT * FROM eccoordinatortbl WHERE ECCId='$TempNICNumber'");
							while($row=mysql_fetch_array($SearchLogin1))
                              {
 		                          $TempNICNo1= $row['NICNumber'];				  
								  
                               }
							   
							   $SearchLogin=mysql_query("SELECT * FROM logintbl WHERE NICNumber='$TempNICNo1'");
							   
							   while($row=mysql_fetch_array($SearchLogin))
                              {
 		                                                  $UserNameTemp= $row['UserName'];	
								  $PasswordTemp= $row['Password'];			  
								  
                               }
							   
							   
							   if($UserNameTemp==$TempUserName)
							   {							   		
							     if($PasswordTemp==$TempPassword)
							     {	
								   							   		
							                echo'<META HTTP-EQUIV="Refresh" Content="0;URL=CoordinatorPage.php?p='.$TempNICNo1.'">';									
							     }
							    else
							    {
							     ?>
							      <script type='text/javascript'> 
							       alert("Not Valide Password, Check it");
								   document.getElementById("password").style.backgroundColor = '#f44336';
			                       document.getElementById("password").style.color = 'black';
			                       document.getElementById("password").focus();							    
                                  </script>
							     <?php
							    }
							   }
							   else
							   {
							    ?>
							      <script type='text/javascript'> 
							        alert("Sorry, Not Valide user name, Check it");
								    document.getElementById("username").style.backgroundColor = '#f44336';
			                        document.getElementById("username").style.color = 'black';
			                        document.getElementById("username").focus();							    
                                  </script>
							     <?php
							   }		  
		
						 }
						 else
						 {
							?>
							  <script type='text/javascript'> 
							    alert("Sorry, Not Valide your Registared Number");
							    document.getElementById("NICNo").style.backgroundColor = '#f44336';
			                    document.getElementById("NICNo").style.color = 'black';
			                    document.getElementById("NICNo").focus();
                              </script>
							<?php
						 }
          			 }															
				   }
														//close the opend database 
														//mysql_close($DatabaseConnection);
				}  
	  											
			 ?>
                            <p class="change_link">
                                Not a member yet ?
                                <a href="StudentRegistration.php" class="to_register">REGISTER - Sign Up</a>
                                
                            </p>                        
                        </form>
              		</div>                   
       		</div>  
    	</section> 
        
</div>
</body>
</html>