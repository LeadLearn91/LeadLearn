<!DOCTYPE>
<html>
<head>
<title>LEAD LEARN</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/book.css" />
    <link href="css/font-awesome.min.css" rel="stylesheet">  
    <link rel="stylesheet" type="text/css" href="css/bg_hospital_infor.css" /> 
<style>
table {
    border-collapse: collapse;
}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

tr:nth-child(even){background-color: #FFF }

th {
    background-color:#F60;
    color: white;
	text-align:center;	
}

h1 {
	color: #333333;
    font-family: 'Roboto Condensed',sans-serif;
		color: #fff;
    font-size: 42px;
    font-weight: 700;
	text-shadow: 0 1px 5px #222222;
	text-align:center;
}

#book-can {
background-color:#F90;
margin-top:20px;
margin-left:45%;
}
img {
margin-left:35%;
}
.bbtn-dialog{
width:100px;
background:#FFFF33;
}
</style>
</head>
<body>

       <h1>UPDATE SHEDULES</h1>
       <p><img src="images/1.jpg" height='142' width='418' /></p>
       <p>&nbsp;       </p>
<form>
<table border="1" align="center">

  <tr>
    
				<th style='width:150px;'>NIC Number</th>
				<th style='width:100px;'>Registration Id</th>
                <th style='width:100px;'>First Name</th>
                <th style='width:100px;'>Last Name</th>
                <th style='width:100px;'>Age</th>
                <th style='width:100px;'>Email Address </th>
                <th style='width:100px;'></th>
                
                
				
                																	
			</tr>
            
  <p>
  <?php
  $ab=$_GET['a'];
  $ac=$_GET['b'];
  $ad=$_GET['c'];
  
  ?>
    <?php
			
     			
				 
	              //connect to the database
				  $ServerConnection = mysql_connect('localhost','root','123456789');			
			  	 //check connection successful
               	  if(!$ServerConnection)
				  {?>
    <script type="text/javascript">alert("Could not connect to the Localhost server")</script>
    
    <?php
				  }
				  else
				 {
				   //connect to the data base
					$DatabaseConnection = mysql_select_db("lldb")  ;
					if(!$DatabaseConnection)
					{?>
    <script type="text/javascript">alert("Could not connect to the Database")</script>
    <?php
					}
					else
					{	
						 
						 $SearchStDetails=mysql_query("SELECT ecf.FirstName, ecf.LastName ,ecf.Age ,ecf.EmailAddress ,ecc.NICNumber,ecc.ECCId FROM ecstaff ecf Inner join  eccoordinatortbl ecc on ecf.NICNumber=ecc.NICNumber");
						  while($RawStDetails=mysql_fetch_array($SearchStDetails))
		  			      {
						 
						  
				
				$x=$RawStDetails['ECCId'] ;
						  //$y=$RawStDetails['EC_ClaimId'] ;
						  //$z=$RawStDetails['StartDate'] ;
						  //$a=$RawStDetails['EndDate'] ;
						  // $b=$RawStDetails['CurrentStatues']; 
						 // $c=$RawStDetails['SType'] ;
		      			     echo "<tr>";
                echo "<td>" . $RawStDetails['NICNumber'] . "</td>";
				echo "<td>" . $RawStDetails['ECCId'] . "</td>";
				echo "<td>" . $RawStDetails['FirstName'] . "</td>";
				echo "<td>" . $RawStDetails['LastName'] . "</td>";
				echo "<td>" . $RawStDetails['Age'] . "</td>";
				echo "<td>" . $RawStDetails['EmailAddress'] . "</td>";
				echo "<td> <a href ='AddFaculty.php?p= $x& q=$ab & r=$ac & s=$ad'><button type='button' id='book-can name ='book-can. onClick='GotoHome1()' class='bbtn-dialog'><i class='fa fa-check-square-o fa-fw'></i> Edit</button></a></td>";	
                
               // echo "<td>" . $RawStDetails['StartDate'] . "</td>";
               // echo "<td>" . $RawStDetails['EndDate'] . "</td>";
               // echo "<td>" . $RawStDetails['CurrentStatues'] . "</td>";
				//echo "<td>" . $RawStDetails['SType'] . "</td>";
                //echo "<td> <a href ='EditShedule.php?p= $x & k=$y & q=$z & r=$a' & s=$b & t=$c><button type='button' id='book-can name ='book-can. onClick='GotoHome1()' class='bbtn-dialog'><i class='fa fa-check-square-o fa-fw'></i> Edit</button></a></td>";	
				
							
		 			   echo "</tr>";   }
					  echo " </table>";
		  	
                     	
					}
                      
		          }
			
                ?>  
    
  </p>
  <table width="493" border="0" align="center">
  <tr>
    <td width="226"><p> &nbsp; To view Closed Shedule List </p></td>
    <td width="257"><button type="button" id="book-can" name ="book-can" onClick="GotoHome1()" class="btn btn-dialog"><i class="fa fa-check-square-o fa-fw"></i> Go Forward</button></td>
  </tr>
</table>
            
        
<button type="button" id="book-can" name ="book-can" onClick="GotoHome()" class="btn btn-dialog"><i class="fa fa-check-square-o fa-fw"></i> Go to Admin Home page</button>
</form>

</body>
<script>
function GotoHome()
{
window.location.href ="AdminPage.php";

}

function GotoHome1()
{
window.location.href ="ViewClosedSheduelList.php";

}

</script>
</html>