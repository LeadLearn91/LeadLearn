<!DOCTYPE>
<html>
<head>
<title>LEAD LEARN</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/book.css" />
    <link href="css/font-awesome.min.css" rel="stylesheet">  
    <link rel="stylesheet" type="text/css" href="css/bg_hospital_infor.css" /> 
<style>
table {
    border-collapse: collapse;
}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

tr:nth-child(even){background-color: #FFF }

th {
    background-color:#F60;
    color: white;
	text-align:center;	
}

h1 {
	color: #333333;
    font-family: 'Roboto Condensed',sans-serif;
		color: #fff;
    font-size: 42px;
    font-weight: 700;
	text-shadow: 0 1px 5px #222222;
	text-align:center;
}

#book-can {
background-color:#F90;
margin-top:20px;
margin-left:45%;
}
img {
margin-left:35%;
}
.bbtn-dialog{
width:100px;
background:#FFFF33;
}
</style>
</head>
<body>

       <h1>CLOSED SHEDULES LIST</h1>
       <p><img src="images/1.jpg" height='142' width='418' /></p>
       <p>&nbsp;       </p>
<form>
<table border="1" align="center">

  <tr>
    <th style='width:150px;'>Shedule Id</th>
				<th style='width:150px;'>Claim Id</th>
				<th style='width:100px;'>Start Date</th>
				<th style='width:100px;'>End Date</th>
				<th style='width:60px;'>Current State</th>
				<th style='width:60px;'>Shedule type</th>
                <th style='width:60px;'>Edit</th>
                																	
			</tr>
            
<?php
			
     			
				 
	              //connect to the database
				  $ServerConnection = mysql_connect('localhost','root','123456789');			
			  	 //check connection successful
               	  if(!$ServerConnection)
				  {?>
					<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
				  }
				  else
				 {
				   //connect to the data base
					$DatabaseConnection = mysql_select_db("lldb")  ;
					if(!$DatabaseConnection)
					{?>
						<script type="text/javascript">alert("Could not connect to the Database")</script><?php
					}
					else
					{	
						 
						 $SearchStDetails=mysql_query("SELECT * FROM shedule ");
						  while($RawStDetails=mysql_fetch_array($SearchStDetails))
		  			      {
						  
						  
				if($RawStDetails['CurrentStatues']==Closed or $RawStDetails['CurrentStatues']==closed)
				{
				     $x=$RawStDetails['SheduleId'] ;
						  $y=$RawStDetails['EC_ClaimId'] ;
						  $z=$RawStDetails['StartDate'] ;
						  $a=$RawStDetails['EndDate'] ;
						   $b=$RawStDetails['CurrentStatues'];
						  $c=$RawStDetails['SType'] ;
		      			     echo "<tr>";
                echo "<td>" . $RawStDetails['SheduleId'] . "</td>";
                echo "<td>" . $RawStDetails['EC_ClaimId'] . "</td>";
                echo "<td>" . $RawStDetails['StartDate'] . "</td>";
                echo "<td>" . $RawStDetails['EndDate'] . "</td>";
                echo "<td>" . $RawStDetails['CurrentStatues'] . "</td>";
				echo "<td>" . $RawStDetails['SType'] . "</td>";
				 echo "<td> <a href ='EditShedule.php?p= $x & k=$y & q=$z & r=$a & s=$b & t=$c'><button type='button' id='book-can name ='book-can. onClick='GotoHome1()' class='bbtn-dialog'><i class='fa fa-check-square-o fa-fw'></i> To Delete</button></a></td>";
				}
				else
				{
				
               	
				}
							
		 			   echo "</tr>";   }
					  echo " </table>";
		  	
                     	
					}
                      
		          }
			
                ?>  
                   
        
<button type="button" id="book-can" name ="book-can" onClick="GotoHome()" class="btn btn-dialog"><i class="fa fa-check-square-o fa-fw"></i> Cancel</button>
</form>
</body>
<script>
function GotoHome()
{
window.location.href ="AdminPage.php";

}

function GotoHome1()
{
window.location.;

}

</script>
</html>