
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Lead Learn</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<!-- <link rel="shortcut icon" href="favicon.ico"> -->
	
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/icomoon.css">

	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<link rel="stylesheet" href="css/style.css">
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body class="boxed">

	<!-- Loader -->
	<div class="fh5co-loader"></div>

	<div id="wrap">

	<div id="fh5co-page">
		<header id="fh5co-header" role="banner">
			<div class="container">
				<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i>dfd</i></a>
                <!--add a logo-->
				<div id="fh5co-logo"><a href="index.html"><img src="images/logo.jpg" alt="Free HTML5 Website Template"></a></div>
  <nav id="fh5co-main-nav" role="navigation">
					<ul>
                    <li><a href="Home.php">Home</a></li>
						<li><a href="about.php">About</a></li>						
						<li><a href="Gellary.php">Gallery</a></li>						
						<li ><a href="contact.php">Contact</a></li>
					</ul>
				</nav>
			</div>
		</header>
		<!-- Header -->

		<div class="fh5co-slider">
			<div class="container">
				<div class="owl-carousel owl-carousel-main">
				  <div><img src="images/1.jpg" alt="Free HTML5 Website Template"></div>
				  <div><img src="images/2.jpg" alt="Free HTML5 Website Template"></div>
				  <div><img src="images/3.jpg" alt="Free HTML5 Website Template"></div>
				</div>
			</div>
		</div>
		<!-- Slider -->
		
		<div id="fh5co-intro" class="fh5co-section">
			<div class="container">
				<div class="row row-bottom-padded-md">
					<div class="col-md-8 col-md-offset-2 text-center ts-intro">
						<h1>University of Lead Learn</h1>
                        <hr/>
						<p class="fh5co-lead">The University, established in 1904, is one of the largest higher education institutions in the UK. We are a world top 100 university and are renowned globally for the quality of our teaching and research.</p>
				  </div>
				</div>
				<div class="row row-bottom-padded-sm">
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<a href="StudentLogin.php" title="Click here"><span class="fh5co-service-icon fh5co-icon-pentagon"><i class="icon-profile-male"></i></span></a>
						  <a href="StudentLogin.php" title="Click here"><h3>Student Login</h3></a>
						  <p>if you are a already member in our university you can upload Extenuating Circumstances (EC) claims and evidence.</p>
					  </div>
					</div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<a href="StaffLogin.php" title="Click here"><span class="fh5co-service-icon fh5co-icon-pentagon"><i class="icon-profile-male"></i></span></a>
							<a href="StaffLogin.php" title="Click here"><h3>Administrative Staff Login</h3></a>
						  <p>As Administrative staff you can log to continue the process of Claim upload</p>
						</div>
					</div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<a href="StudentLogin.php" title="Click here"><span class="fh5co-service-icon fh5co-icon-pentagon"><i class="icon-tools-2"></i></span></a>
							<a href="StudentLogin.php" title="Click here"><h3>About Claim Upload</h3></a>
							<p>Here provide some example of Claims format to submit all student according to their faculty.</p>
					  </div>
					</div>
				</div>
				<div class="row row-bottom-padded-sm">
					<div class="col-md-6">
						<p><img src="images/welcome.jpeg" alt="University of Leed Learn" width="574" height="414" class="img-responsive img-bordered"></p>
				  </div>
			  <div class="col-md-6 padded-top">
						<h3>The Lead Learn</h3>
						<p>The strength of our academic expertise combined with the breadth of   disciplines we cover, provides a wealth of opportunities and has real   impact on the world in cultural, economic and societal ways. </p>
						<p>The University strives to achieve academic excellence within an   ethical framework informed by our values of integrity, equality and   inclusion, community and professionalism. </p>
	  <ul class="ul_style_1">
							<li>University of the Year | The Times and The Sunday Times Good University Guide 2017 </li>
							<li>Member of the Russell Group </li>
						</ul>
				  </div>
				</div>

				<div class="row row-bottom-padded-sm">
					<div class="col-md-4">
						<div class="fh5co-service text-center">
							<img src="images/gaduateStudent.jpg" alt="Gaduate Student" height="1103" class="img-responsive img-bordered">
						  <h3>Gaduate Student</h3>
							<p>Lead Lear have more gaduate student cloud.they are increas knowladge waiting us </p>
						</div>
				  </div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
						  <img src="images/lec.jpg" alt="Lecture panel"  height="1103" class="img-responsive img-bordered">
						  <h3>Lecture panel</h3>
							<p>Lead Learn has more exprienced and kidness lecture panel and to motivate our student.</p>
						</div>
				  </div>
					<div class="col-md-4">
						<div class="fh5co-service text-center">
						  <img src="images/std.jpg" alt="Free HTML5 Bootstrap Template by FreeHTML5.co"  height="363" class="img-responsive img-bordered">
						  <h3>Espacial Event</h3>
							<p>Lead learn has offers for our student.festivals, exsibitions and lot of facilities</p>
						</div>
				  </div>
				</div>

			</div>
		</div>

		<footer id="fh5co-footer" role="contentinfo">
			<div class="container">
				<div class="row row-bottom-padded-sm">
					<div class="col-md-4 col-sm-12">
						<div class="fh5co-footer-widget">
							<h3>About Us</h3>
							<p>The University, established in 1904, is one of the largest higher education institutions in the UK. We are a world top 100 university and are renowned globally for the quality of our teaching and research..</p>
						</div>
					</div>
					<div class="col-md-3 col-md-push-1 col-sm-12 col-sm-push-0">
						<div class="fh5co-footer-widget">
							<h3>Quick Links</h3>
							<ul class="fh5co-footer-link">
								<li><a href="Home.php">Home</a></li>
								<li><a href="Gellary.php">Gallery</a></li>
								<li><a href="contact.php">Contact</a></li>
								<li><a href="StudentLogin.php">Upload Student claim</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md-3 col-md-push-2 col-sm-12 col-sm-push-0">
						
						<div class="fh5co-footer-widget">
							<h3>Follow us</h3>
							<ul class="fh5co-social">
								<li class="facebook"><a href="#"><i class="icon-facebook2"></i></a></li>
								<li class="twitter"><a href="#"><i class="icon-twitter"></i></a></li>
								<li class="linkedin"><a href="#"><i class="icon-linkedin"></i></a></li>
								<li class="message"><a href="#"><i class="icon-mail"></i></a></li>
							</ul>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-12">
						<div class="fh5co-copyright">
							<p class="pull-left">&copy; 2017 Free Template. All Rights Reserved. </p>
							<p class="pull-right">Designed by <a href="http://freehtml5.co" target="_blank">lead learn</a> web development team: <a href="http://akamilaudayanga.tk" target="_blank">We are</a></p>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-chevron-down"></i></a>
	</div>
	
	<script src="js/jquery.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>

