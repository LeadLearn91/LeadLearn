
<!DOCTYPE html>
<head>
	<meta charset="UTF-8" />
    <title>Leed Learn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
    <script src="js/LoginCheck.js" type="text/javascript"></script>
    <script type="text/javascript">
		function ValidateRegForm()
		{
			/*Assigne input values into variable*/
            
			var TempEmailIdValidete = document.RegFrm.EmailId.value;
			var TempContentValidate = document.RegFrm.Content.value;						
			
			
			
              
			/*check conditions*/
			
			var numeric = /^[0-9]+$/;
            var alpha = /^[a-zA-Z]+$/;
			
            
			/*validate Customer NIC Number text field*/
			if (TempEmailIdValidete.match(" "))
	        {
				
				alert("Email address out of fleld. Check and enter again");
			    document.getElementById("EmailId").style.backgroundColor = '#f44336';
			    document.getElementById("EmailId").style.color = 'black';			
				document.getElementById("EmailId").value = "";				
			    document.getElementById("EmailId").focus();			  
			    return false;
			}
			else if (TempEmailIdValidete.match(numeric))
	        {
				
				alert(" Incorrect Email ID formate insertion");
			    document.getElementById("EmailId").style.backgroundColor = '#f44336';
			    document.getElementById("EmailId").style.color = 'black';			
				document.getElementById("EmailId").value = "";				
			    document.getElementById("EmailId").focus();			  
			    return false;
			}
			else if (TempEmailIdValidete.length>=12)
	        {
				
				alert("Email id must have 5 - 12");
			    document.getElementById("EmailId").style.backgroundColor = '#f44336';
			    document.getElementById("EmailId").style.color = 'black';			
				document.getElementById("EmailId").value = "";				
			    document.getElementById("EmailId").focus();			  
			    return false;
			}
			else if (TempEmailIdValidete.length<5)
	        {
				
				alert("Email id must have 5 - 12");
			    document.getElementById("EmailId").style.backgroundColor = '#f44336';
			    document.getElementById("EmailId").style.color = 'black';			
				document.getElementById("EmailId").value = "";				
			    document.getElementById("EmailId").focus();			  
			    return false;
			}
			
			 
			
			// validate pasword text field
			
			else if (TempContentValidate.match(" "))
	        {
				
				alert("Email Containt  out of field");
			    document.getElementById("Content").style.backgroundColor = '#f44336';
			    document.getElementById("Content").style.color = 'black';			
				document.getElementById("Content").value = "";				
			    document.getElementById("Content").focus();			  
			    return false;
			}	
				
			else if (TempContentValidate.length>200)
	        {
				
				alert("email contant between 50 - 200");
			    document.getElementById("Content").style.backgroundColor = '#f44336';
			    document.getElementById("Content").style.color = 'black';			
				document.getElementById("Content").value = "";				
			    document.getElementById("Content").focus();			  
			    return false;
			}
			else if (TempContentValidate.length<50)
	        {
				
				alert("Email Content between 10 - 50 ");
			    document.getElementById("Content").style.backgroundColor = '#f44336';
			    document.getElementById("Content").style.color = 'black';			
				document.getElementById("Content").value = "";				
			    document.getElementById("Content").focus();			  
			    return false;
			}
			// validate pasword text field
			
			else
			{			  
			   return true;
			}
			}
			</script>

</head>
	<body>
    
    	<div class="container">
        <!-- Codrops top bar -->
        	<div class="codrops-top">
            	<span class="right">
                  <?php
	                
					$_POST['NICNumber']=trim($_GET['r']);
					$_POST['EmailAddress']=trim($_GET['q']);
					$_POST['ClaimId']=trim($_GET['p']);
					
	              ?> 
                </span>
            <div class="clr"></div>
            </div><!--/ Codrops top bar -->
      	<header>
        <br/>
        	<h1>Send Email<span> -Claim Submission</span></h1>
    </header>
        
        <section>				
<div id="container_demo" >
            	<a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                	<div id="login" class="animate form">
                    	<form method="post" name="RegFrm" id="loginFrm">      
                       <h1>Email Attachment</h1> 
  <p> 
                                <label for="SheduleId" class="uname" data-icon="N" >NICNumber </label>
                                <input id="NICNumber" name="NICNumber" type="text" readonly="readonly" title="Con not Edit" onBlur="checkAvailability()" value="<?php echo $_POST['NICNumber']?>"/> <span id="user-availability-status"></span>
                            </p>
                            <p> 
                                <label for="ECSID" class="uname" data-icon="u" >Email Id</label>
                                <input id="EmailId" name="EmailId" type="text" onBlur="checkAvailability()"   value="<?php echo $_POST['EmailId'] ?>"/> <span id="user-availability-status" ></span>
                                <label for="ECSID" class="uname" data-icon="u" ></label>
                            </p>
                            
                            <p> 
                                <label for="StDate" class="youpasswd" data-icon="p">Email Address </label>
                                <input id="EmailAddress" name="EmailAddress" type="text" readonly="readonly" title="Con not Edit" value="<?php echo $_POST['EmailAddress']?>" /> 
                            </p>
                            <p> 
                                <label for="EndDate" class="youpasswd" data-icon="p">Claim Id</label>
                                <input id="ClaimId" name="ClaimId" type="text" readonly="readonly" title="Con not Edit" value="<?php echo $_POST['ClaimId']?>" /> 
                            </p>
                            <p> 
                                <label for="EndDate" class="youpasswd" data-icon="p">Content</label>
                                <input id="Content" name="Content" type="text" value="<?php echo $_POST['Content']?>" /> 
                            </p>
                           

                            <p class="login button">
                              <input type="submit" name="Submit" value="Submit"  onClick="return ValidateRegForm()" />
                            </p>
                          <?php
     			 if (isset($_POST["Submit"]))
      			 {		      		
					// initialize the variable using above insertion
				    												
					$TempNICNumber=trim($_POST['NICNumber']);
					$TempEmailId=trim($_POST['EmailId']);
					$TempClaimId=trim($_POST['ClaimId']);
					$TempContent=trim($_POST['Content']);
					$dateDisplay=trim(date("Y/m/d"));
					
					
				
					//$PassStudentNICNo1=base64_encode($PassStudentLoginNICNumber);													
					//connect to the database
					$ServerConnection = mysql_connect('localhost','root','123456789');			
			  		//check connection successful
               		if(!$ServerConnection)
					{?>
						<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
					}
					else
					{
					  //connect to the data base
					  $DatabaseConnection = mysql_select_db("lldb")  ;
					  if(!$DatabaseConnection)
					  {?>
						<script type="text/javascript">alert("Could not connect to the Database")</script><?php
					  }
					  else
					  {
					    $InsertCustomerDetails=mysql_query("insert into email values('$TempEmailId','$TempContent','$dateDisplay','$TempNICNumber','$TempClaimId')");
						 if(!$InsertCustomerDetails)
						 {?>
							 <script type="text/javascript">
							  alert("this Email alredy sent. Enter correct shedule")
							  document.getElementById("EmailId").style.backgroundColor = '#00E676';
			    			  document.getElementById("EmailId").style.color = 'black';			
							  document.getElementById("EmailId").value = "";				
			    			  document.getElementById("EmailId").focus();
                             </script><?php
						  }
						  else
						 {?>
						   <script type="text/javascript">alert("Email sent")</script><?php							
															
						}
          			 }															
				   }
														//close the opend database 
														//mysql_close($DatabaseConnection);
				}  
	  											
			 ?>
                                                  
                      </form>
              		</div>                   
       		</div>  
    	</section> 
        
</div>
</body>
</html>