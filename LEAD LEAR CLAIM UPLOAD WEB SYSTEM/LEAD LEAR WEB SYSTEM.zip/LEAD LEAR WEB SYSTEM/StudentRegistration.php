<!DOCTYPE html>
<html>
<head>
	<title>Lead Learn</title>
	<link rel="stylesheet" href="css/UserReg.css">    
    <script src="js/Log_check_for_Reg.js" type="text/javascript"></script>
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
	    <script src="js/fvRegistration.js" type="text/javascript"></script>
</head>

<body>

	<div id="wrapper">
    <br/>
    <br/>
    	<h1>Student Registration</h1>
	</div>

<form class="form1"  name="form1" method="post" action="Insert_Register_Infor.php">
	<div class="form-style-9">
  	<table width="678" height="589" border="0">
    <tr>
      <td width="312">NIC Number</td>
      <td width="11">&nbsp;</td>
      <td width="338">&nbsp;</td>
    </tr>
    <tr>
      <td width="312"><input type="text" class="field-style field-split align-left" size="45%" name="SNic" id="SNic"  /></td>
      <td width="11">&nbsp;</td>
      <td width="338">&nbsp;</td>
    </tr>
    <tr>
      <td width="312" height="27">First Name</td>
      <td width="11">&nbsp;</td>
      <td width="338">Last Name</td>
    </tr>
    
    <tr>
      <td><label for="fname"></label>
      <input type="text" class="field-style field-split align-left" size="45%" name="fname" id="fname"  /></td>
      <td>&nbsp;</td>
      <td><label for="lname"></label>
      <input type="text" class="field-style field-split align-left" size="45%" name="lname" id="lname" /></td>
    </tr>
  
    <tr>
      <td width="312">Date of birth</td>
      <td width="11">&nbsp;</td>
      <td width="338">Age</td>
    </tr>
    
    <tr>
     	<td> <input type="text" class="field-style field-split align-left" size="45%" name="DOB" id="DOB" /></td>  	    

      <td>&nbsp;</td>
      <td><label for="age"></label>
      <input type="text" class="field-style field-split align-left" size="45%" name="age" id="age" /></td>
    </tr>


    <tr>
      <td width="312">Gender</td>
      <td width="11">&nbsp;</td>
      <td width="338">Email</td>
    </tr>
  
  	<tr>
      <td><label for="phone"></label>
      <select name="gender" class="field-style field-split align-left">
    		<option value="Male">Male</option>
    		<option value="Femail">Female</option>
    	</select>
      </td>
      <td>&nbsp;</td>
      <td><label for="email"></label>
      <input type="text" class="field-style field-split align-left" size="45%" name="email" id="email"/></td>
    </tr>
    <tr>
      <td >&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td ><label for="email">&nbsp;</label><strong>Address</strong></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    
    <tr>
      <td height="21" colspan="3">&nbsp;</td>
    </tr>
    
    <tr>
      <td width="312">Street</td>
      <td width="11">&nbsp;</td>
      <td width="338">City</td>
    </tr>
    
    <tr>
      <td><label for="City"></label>
      <input type="text" class="field-style field-split align-left" size="45%" name="street" id="street" /></td>
      <td>&nbsp;</td>
      <td><label for="uname"></label>
      <input type="text" class="field-style field-split align-left" size="45%" name="city" id="city" onBlur="checkAvailability()"/> </td>
      </tr>
 	<tr>
      <td width="312">Postal Code</td>
      <td width="11">&nbsp;</td>
      <td width="338">Country</td>
    </tr>
    
    <tr>
      <td><label for="City"></label>
      <input type="text" class="field-style field-split align-left" size="45%" name="pstcd" id="pstcd" /></td>
      <td>&nbsp;</td>
      <td><label for="uname"></label>
      <input type="text" class="field-style field-split align-left" size="45%" name="Country" id="Country" onBlur="checkAvailability()"/> </td>
      </tr>
    <tr>
      <td width="312"></td>
      <td width="11">&nbsp;</td>
      <td width="338">  <span id="user-availability-status" ></span></td>
    </tr>
      <tr>
      <td ><label for="email">&nbsp;</label><strong>User Acount</strong></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    </tr>
      <tr>
      <td >&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="312">User Name</td>
      <td width="11">&nbsp;</td>
      <td width="338">&nbsp;</td>
    </tr>

    <tr>
      <td><label for="Password"></label>
      <input type="password" class="field-style field-split align-left" size="45%" name="username" id="username" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="312">Password</td>
      <td width="11">&nbsp;</td>
      <td width="338">Confirm Password</td>
    </tr>

    <tr>
      <td><label for="Password"></label>
      <input type="password" class="field-style field-split align-left" size="45%" name="password" id="password" /></td>
      <td>&nbsp;</td>
      <td><label for="cpassword"></label>
      <input type="password" class="field-style field-split align-left" size="45%" name="cpassword" id="cpassword" /></td>
    </tr>  
    
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr>
            
    <tr>
        <td><input type="reset" value=" Reset " id ="Reset" onClick="return validateForm()" /></td>
        <td>&nbsp;</td>
        <td>
        <input type="submit" value="Register" id ="Register" onClick="return validateForm()" />
        </td>
    </tr>
  </table>
  </div>
</form>

</body>
</html>
