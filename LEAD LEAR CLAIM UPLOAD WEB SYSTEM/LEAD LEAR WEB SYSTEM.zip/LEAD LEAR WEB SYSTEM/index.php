
<!DOCTYPE html>
<head>
	<meta charset="UTF-8" />
    <title>Welcome to Leed Learn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
    <script src="js/LoginCheck.js" type="text/javascript"></script>

</head>
	<body>
    	<div class="container">
        <!-- Codrops top bar -->
        	<div class="codrops-top">
            	<span class="right">                </span>
            <div class="clr"></div>
            </div>
<!--/ Codrops top bar -->
      	<header>
        <br />
        <br />
        	<h1>Welcome To University of <span> - Lead Learn </span></h1>
</header>
        <br />
        <section>				
        	<div id="container_demo" >
            	<a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                	<div id="login" class="animate form">
                    	<form  action="login.php" autocomplete="on" method="post">      
                       <h1>LEAD LEARN </h1> 
                            <div><img src="images/welcome.jpeg" width="439" height="246"/></div>
                            
                            <p class="change_link">
                                Join with LEAD LEARN University 
                                <a href="Home.php" class="to_register" title="Click here">Welcome</a>                            </p>                        
                        </form>
              		</div>                   
       		</div>  
    	</section> 
</div>
</body>
</html>