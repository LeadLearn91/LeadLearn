
<!DOCTYPE html>
<head>
	<meta charset="UTF-8" />
    <title>Leed Learn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
    <script src="js/LoginCheck.js" type="text/javascript"></script>
    <script type="text/javascript">
		function ValidateLoginForm()
		{
			/*Assigne input values into variable*/         
			
								
			var TempStDateValidate=document.loginFrm.StDate.value;
			var TempEndDateValidate = document.loginFrm.EndDate.value;						
			var TempECCtypeValidate=document.loginFrm.ECCtype.value;
			
              
			/*check conditions*/
			
			var numeric = /^[0-9]+$/;
            var alpha = /^[a-zA-Z]+$/;
			
            
			/*validate Customer NIC Number text field*/
			
			
			 if (TempStDateValidate.match(" "))
	        {
				
				alert("Start date out of field");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}	
				else if (TempStDateValidete.match(alpha))
	        {
				
				alert(" Incorrect Start date formate");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}	
			else if (TempStDateValidate.length>12)
	        {
				
				alert("Incorrect Start date length");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}
			else if (TempStDateValidate.length<6)
	        {
				
				alert(" Incorrect Start date length");
			    document.getElementById("StDate").style.backgroundColor = '#f44336';
			    document.getElementById("StDate").style.color = 'black';			
				document.getElementById("StDate").value = "";				
			    document.getElementById("StDate").focus();			  
			    return false;
			}
			// validate pasword text field
			
			else if (TempEndDateValidate.match(" "))
	        {
				
				alert("End date out of field");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}	
				else if (TempEndDateValidete.match(alpha))
	        {
				
				alert(" Incorrect End date formate");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}	
			else if (TempEndDateValidate.length>12)
	        {
				
				alert("Incorrect End date length");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}
			else if (TempEndDateValidate.length<6)
	        {
				
				alert(" Incorrect End date length");
			    document.getElementById("EndDate").style.backgroundColor = '#f44336';
			    document.getElementById("EndDate").style.color = 'black';			
				document.getElementById("EndDate").value = "";				
			    document.getElementById("EndDate").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.match(" "))
	        {
				
				alert("EC claim type out of fleld. Check and enter again");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.match(numeric))
	        {
				
				alert(" Incorrect EC claim type formate");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.length>=12)
	        {
				
				alert(" Incorrect EC claim type length");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else if (TempECCtypeValidete.length<5)
	        {
				
				alert(" Incorrect EC claim type length");
			    document.getElementById("ECCtype").style.backgroundColor = '#f44336';
			    document.getElementById("ECCtype").style.color = 'black';			
				document.getElementById("ECCtype").value = "";				
			    document.getElementById("ECCtype").focus();			  
			    return false;
			}
			else
			{			  
			   return true;
			}
			}
			</script>

</head>
	<body>
      <?php
$_POST['$SID'] =$_GET['p'].trim();
$_POST['$CID'] =$_GET['k'].trim();
$_POST['StDate']=$_GET['q'].trim();
$_POST['EndDate']=$_GET['r'].trim();
$_POST['ECCtype']=$_GET['t'].trim();
$_POST['ECS']=$_GET['s'].trim();

?>

    	<div class="container">
        <!-- Codrops top bar -->
        	<div class="codrops-top">
            	<span class="right">
                   
                </span>
            <div class="clr"></div>
            </div><!--/ Codrops top bar -->
      	<header>
        <br/>
        	<h1>Edit shedule <span> - Managment of Claim</span></h1>
    </header>
        
        <section>				
        	<div id="container_demo" >
            	<a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                	<div id="login" class="animate form">
                    	<form method="post" name="loginFrm" id="loginFrm">      
                       <h1>Shedule</h1> 
                       <p> 
                                <label for="SheduleId" class="uname" data-icon="S" >Sedule Id </label>
                                <input id="SheduleId" name="SheduleId" type="text" readonly="readonly" title="Cannot Edit"onBlur="checkAvailability()" value="<?php echo $_POST['$SID'].trim()?>"/> <span id="user-availability-status"></span>
                            </p>
                            
                            
                          
  
                            <p> 
                                <label for="ECSID" class="uname" data-icon="u" > Claim Subbmission Id</label>
                                <input id="ECSID" name="ECSID" type="text" readonly="readonly" onBlur="checkAvailability()" value="<?php echo $_POST['$CID'].trim();?>"/> <span id="user-availability-status" ></span>
                            </p>
                            
                            <p> 
                                <label for="StDate" class="youpasswd" data-icon="p"> Start Date</label>
                                <input id="StDate" name="StDate" type="text" placeholder="eg yyyy/mm/dd" value="<?php echo $_POST['StDate']?>" /> 
                            </p>
                            <p> 
                                <label for="EndDate" class="youpasswd" data-icon="p"> End Date</label>
                                <input id="EndDate" name="EndDate" type="text" placeholder="eg yyyy/mm/dd" value="<?php echo $_POST['EndDate']?>" /> 
                            </p>
                            
                            <p> 
                                <label for="ECCtype" class="youpasswd" data-icon="p">Claim type</label>
                                <input id="ECCtype" name="ECCtype" type="text" placeholder="Claim Type" value="<?php echo $_POST['ECCtype']?>" /> 
                            </p>
                            <p> 
                                <label for="ECCtype" class="youpasswd" data-icon="p">Current State</label>
                                <input id="ECCtype" name="ECCtype" type="text" placeholder="Claim Type" value="<?php echo $_POST['ECS']?>" /> 
                            </p>
                      <p class="keeplogin"> 
                                <input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
                                <label for="loginkeeping">Keep me logged in</label>
                            </p>
                            
                            <p class="login button"> 
                                <input type="submit" name="Update" value="Update"   title="Go to shedule view page"onclick="return ValidateLoginForm()" /> 
                            </p>
                            <p class="Delete button">
                              <input type="submit" name="Delete" value="Delete"   title="Go to shedule view page"onClick="return ValidateLoginForm()" />
                            </p>
                            
                           
                            <?php
					if(isset($_POST["Delete"]))
					{		  
		  			   $TempSheduleId=$_POST['$SID'].trim();
		               $ServerConnection = mysql_connect('localhost','root','123456789');			
		              //check connection successful
                      if(!$ServerConnection)
		              {?>
			            <script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
		              }
		              else
		              {
			            //connect to the data base
			             $DatabaseConnection = mysql_select_db("lldb")  ;
			             if(!$DatabaseConnection)
			             {?>
				           <script type="text/javascript">alert("Could not connect to the Database")</script><?php
			             }
			             else
			             {
			              //search student details
		                   $SearchDetailsDelete=mysql_query("DELETE * FROM shedule WHERE  SheduleId='$TempSheduleId'");	
						   $StudentCountrows = mysql_num_rows($SearchDetailsDelete);
						   if($StudentCountrows==1)
						   {
                               ?>
							      <script type='text/javascript'> 
							       alert("Permanatly delete this record -: " & $TempSheduleId);								   						    
                                  </script>
							   <?php							    								  
		                    }
							else
							{
							   ?>
							      <script type='text/javascript'> 
							       alert("Cannot delete this record -: " & $TempSheduleId);								   						    
                                  </script>
							   <?php
							}
		                  }
		                }
				      }		   
		         ?> 
                 
                          <?php
     			 if (isset($_POST["Update"]))
      			 {		      		
					// initialize the variable using above insertion
				    												
					echo $TempSheduleId=$_POST['SheduleId'].trim();
					 echo $TempECSID=$_POST['ECSID'].trim();
					echo $TempStDate=$_POST['StDate'].trim();
					echo $TempEndDate=$_POST['EndDate'].trim();
					echo $TempECCtype=$_POST['ECCtype'].trim();
					echo $currents=$_POST['ECS'].trim();
					
				   //$PassStudentNICNo1=base64_encode($PassStudentLoginNICNumber);													
					//connect to the database
					$ServerConnection = mysql_connect('localhost','root','123456789');			
			  		//check connection successful
               		if(!$ServerConnection)
					{?>
						<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
					}
					else
					{
					  //connect to the data base
					  $DatabaseConnection = mysql_select_db("lldb")  ;
					  if(!$DatabaseConnection)
					  {?>
						<script type="text/javascript">alert("Could not connect to the Database")</script><?php
					  }
					  else
					  {
					  ?>
					  <script type='text/javascript'> 
							       alert("Permanatly update this record");								   						    
                                  </script>
							   <?php
					    $Update1= mysql_query("UPDATE shedule SET  SheduleId='$TempSheduleId',EC_ClaimId='$TempECSID' ,StartDate='$TempStDat',EndDate='$TempEndDate',CurrentStatues='$currents',SType='$TempECCtype', WHERE  SheduleId='$TempSheduleId' and EC_ClaimId='$TempECSID'");
						if($Update1==1)
						   {
						   ?>
					  <script type='text/javascript'> 
							       alert("success");								   						    
                                  </script>
							   <?php
						   }
						   else
						   {
						   ?>
					  <script type='text/javascript'> 
							       alert("un success");								   						    
                                  </script>
							   <?php
						   }
          			 }															
				   }
														//close the opend database 
														//mysql_close($DatabaseConnection);
				}  
				
				
				
				
				
				
	  											
			 ?>
                            <p class="change_link">
                                go to administrator page ?
                                <a href="AdminPage.php" class="to_register">click here</a> </p>                        
                      </form>
              		</div>                   
       		</div>  
    	</section> 
        
</div>
</body>
</html>