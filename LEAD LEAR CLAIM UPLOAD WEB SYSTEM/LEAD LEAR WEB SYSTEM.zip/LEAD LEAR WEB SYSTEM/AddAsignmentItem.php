
<!DOCTYPE html>
<head>
	<meta charset="UTF-8" />
    <title>Leed Learn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style3.css" />
    <script src="js/Check_Ava_Users.js" type="text/javascript"></script>
    <script src="js/LoginCheck.js" type="text/javascript"></script>
    <script type="text/javascript">
		function ValidateRegForm()
		{
			/*Assigne input values into variable*/
            
			var TempAssIdValidete = document.RegFrm.AssId.value;
			var TempSubjectValidate = document.RegFrm.Subject.value;						
			var TempGradeValidate=document.RegFrm.Grade.value;
			
			
              
			/*check conditions*/
			
			var numeric = /^[0-9]+$/;
            var alpha = /^[a-zA-Z]+$/;
			
            
			/*validate Customer NIC Number text field*/
			if (TempAssIdValidete.match(" "))
	        {
				
				alert("Assignment Id out of fleld. Check and enter again");
			    document.getElementById("AssId").style.backgroundColor = '#f44336';
			    document.getElementById("AssId").style.color = 'black';			
				document.getElementById("AssId").value = "";				
			    document.getElementById("AssId").focus();			  
			    return false;
			}
			else if (TempAssIdValidete.match(numeric))
	        {
				
				alert(" Incorrect Assignmetformate");
			    document.getElementById("AssId").style.backgroundColor = '#f44336';
			    document.getElementById("AssId").style.color = 'black';			
				document.getElementById("AssId").value = "";				
			    document.getElementById("AssId").focus();			  
			    return false;
			}
			else if (TempAssIdValidete.length>=12)
	        {
				
				alert("assignment id must have 5 - 12");
			    document.getElementById("AssId").style.backgroundColor = '#f44336';
			    document.getElementById("AssId").style.color = 'black';			
				document.getElementById("AssId").value = "";				
			    document.getElementById("AssId").focus();			  
			    return false;
			}
			else if (TempAssIdValidete.length<5)
	        {
				
				alert("assignment id must have 5 - 12");
			    document.getElementById("AssId").style.backgroundColor = '#f44336';
			    document.getElementById("AssId").style.color = 'black';			
				document.getElementById("AssId").value = "";				
			    document.getElementById("AssId").focus();			  
			    return false;
			}
			
			 //check user name text field
			
			else if (TempSubjectValidate.match(" "))
	        {
				
				alert("EC subject out of field");
			    document.getElementById("Subject").style.backgroundColor = '#f44336';
			    document.getElementById("Subject").style.color = 'black';			
				document.getElementById("Subject").value = "";				
			    document.getElementById("Subject").focus();			  
			    return false;
			}
			else if (TempSubjectValidete.match(numeric))
	        {
				
				alert(" Incorrect Subject formate");
			    document.getElementById("Subject").style.backgroundColor = '#f44336';
			    document.getElementById("Subject").style.color = 'black';			
				document.getElementById("Subject").value = "";				
			    document.getElementById("Subject").focus();			  
			    return false;
			}		
			else if (TempSubjectValidate.length>40)
	        {
				
				alert("between 5 -40");
			    document.getElementById("Subject").style.backgroundColor = '#f44336';
			    document.getElementById("Subject").style.color = 'black';			
				document.getElementById("Subject").value = "";				
			    document.getElementById("Subject").focus();			  
			    return false;
			}
			else if (TempSubjectValidate.length<5)
	        {				
				alert("between 5 -40");
			    document.getElementById("Subject").style.backgroundColor = '#f44336';
			    document.getElementById("Subject").style.color = 'black';			
				document.getElementById("Subject").value = "";				
			    document.getElementById("Subject").focus();			  
			    return false;
			}
			
			// validate pasword text field
			
			else if (TempGradeValidate.match(" "))
	        {
				
				alert("Grade out of field");
			    document.getElementById("Grade").style.backgroundColor = '#f44336';
			    document.getElementById("Grade").style.color = 'black';			
				document.getElementById("Grade").value = "";				
			    document.getElementById("Grade").focus();			  
			    return false;
			}	
				else if (TempGradeValidete.match(numeric))
	        {
				
				alert(" Incorrect grade formate");
			    document.getElementById("Grade").style.backgroundColor = '#f44336';
			    document.getElementById("Grade").style.color = 'black';			
				document.getElementById("Grade").value = "";				
			    document.getElementById("Grade").focus();			  
			    return false;
			}	
			else if (TempGradeValidate.length>20)
	        {
				
				alert("grade between 6 - 20");
			    document.getElementById("Grade").style.backgroundColor = '#f44336';
			    document.getElementById("Grade").style.color = 'black';			
				document.getElementById("Grade").value = "";				
			    document.getElementById("Grade").focus();			  
			    return false;
			}
			else if (TempGradeValidate.length<6)
	        {
				
				alert("grade between 6 - 20 ");
			    document.getElementById("Grade").style.backgroundColor = '#f44336';
			    document.getElementById("Grade").style.color = 'black';			
				document.getElementById("Grade").value = "";				
			    document.getElementById("Grade").focus();			  
			    return false;
			}
			// validate pasword text field
			
			
			else
			{			  
			   return true;
			}
			}
			</script>

</head>
	<body>
    
    	<div class="container">
        <!-- Codrops top bar -->
        	<div class="codrops-top">
            	<span class="right">
                  <?php
	$_POST['ECSID']=$_GET['p'];
	?> 
                </span>
            <div class="clr"></div>
            </div><!--/ Codrops top bar -->
      	<header>
        <br/>
        	<h1>Add New Assignment item <span> - CLAIM Submission</span></h1>
    </header>
        
        <section>				
        	<div id="container_demo" >
            	<a class="hiddenanchor" id="toregister"></a>
                <a class="hiddenanchor" id="tologin"></a>
                <div id="wrapper">
                	<div id="login" class="animate form">
                    	<form method="post" name="RegFrm" id="loginFrm">      
                       <h1>Assignment Item</h1> 
                       <p> 
                                <label for="SheduleId" class="uname" data-icon="S" >Assignmet  Id </label>
                                <input id="AssId" name="AssId" type="text" placeholder="Assignment Id" onBlur="checkAvailability()" value="<?php echo $_POST['AssId']?>"/> <span id="user-availability-status"></span>
                            </p>
                            <p> 
                                <label for="ECSID" class="uname" data-icon="u" > Claim Subbmission Id</label>
                                <input id="ECSID" name="ECSID" type="text" placeholder="ClaimId" onBlur="checkAvailability()"  readonly="readonly " value="<?php echo $_POST['ECSID'] ?>"/> <span id="user-availability-status" ></span>
                            </p>
                            
                            <p> 
                                <label for="StDate" class="youpasswd" data-icon="p"> Subject </label>
                                <input id="Subject" name="Subject" type="text" placeholder="subject" value="<?php echo $_POST['Subject']?>" /> 
                            </p>
                            <p> 
                                <label for="EndDate" class="youpasswd" data-icon="p">Grade</label>
                                <input id="Grade" name="Grade" type="text" placeholder="Grade" value="<?php echo $_POST['Grade']?>" /> 
                            </p>
                            
                            <p>&nbsp;</p>
<p class="keeplogin"> 
                                <input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> 
                                <label for="loginkeeping">Keep me logged in</label>
                            </p>
                            
                            <p class="login button">
                              <input type="submit" name="Submit" value="Submit"  onClick="return ValidateRegForm()" />
                            </p>
                          <?php
     			 if (isset($_POST["Submit"]))
      			 {		      		
					// initialize the variable using above insertion
				    												
					$TempAssId=$_POST['AssId'];
					$TempECSID=$_POST['ECSID'];
					$TempSub=$_POST['Subject'];
					$TempGrade=$_POST['Grade'];
					
					
				
					//$PassStudentNICNo1=base64_encode($PassStudentLoginNICNumber);													
					//connect to the database
					$ServerConnection = mysql_connect('localhost','root','123456789');			
			  		//check connection successful
               		if(!$ServerConnection)
					{?>
						<script type="text/javascript">alert("Could not connect to the Localhost server")</script>;<?php
					}
					else
					{
					  //connect to the data base
					  $DatabaseConnection = mysql_select_db("lldb")  ;
					  if(!$DatabaseConnection)
					  {?>
						<script type="text/javascript">alert("Could not connect to the Database")</script><?php
					  }
					  else
					  {
					    $InsertCustomerDetails=mysql_query("insert into assignmentitem  values('$TempAssId','$TempECSID','$TempSub','$TempGrade')");
						 if(!$InsertCustomerDetails)
						 {?>
							 <script type="text/javascript">
							  alert("this assignment item alredy existing. Enter correct shedule")
							  document.getElementById("SheduleId").style.backgroundColor = '#00E676';
			    			  document.getElementById("SheduleId").style.color = 'black';			
							  document.getElementById("SheduleId").value = "";				
			    			  document.getElementById("SheduleId").focus();
                             </script><?php
						  }
						  else
						 {?>
						   <script type="text/javascript">alert("Assignment item is added")</script><?php
							// insert data into login table
							$type='Student';
							 $InsertCustomerDetails=mysql_query("insert into logintbl values('$PassStdNicNumber','$PassUserName','$PassPassword','$type')");						 
							 
															
						}
          			 }															
				   }
														//close the opend database 
														//mysql_close($DatabaseConnection);
				}  
	  											
			 ?>
                            <p class="change_link">
                                go to administrator page ?
                                <a href="AdminPage.php" class="to_register">click here</a> </p>                        
                      </form>
              		</div>                   
       		</div>  
    	</section> 
        
</div>
</body>
</html>