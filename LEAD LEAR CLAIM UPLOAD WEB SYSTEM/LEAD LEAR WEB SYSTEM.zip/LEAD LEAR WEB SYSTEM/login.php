<?php session_start();
include("config.php");
if(isset($_POST['login']))
{

	$username = $_POST['username']);
	$password =  $_POST['password'], $mysqli);
	
	$q = "SELECT * FROM logintbl WHERE UserName='$username' and Password='$password'";
	if($res = $mysqli->query($q))
	{
		if($res->num_rows > 0)
		{
			$_SESSION['username'] = $username;
			echo'<META HTTP-EQUIV="Refresh" Content="0;URL=Home.php">';
			exit;
		}
		else
		{
			echo '<script language="javascript">';
echo 'alert("INVALID USERNAME OR PASSWORD")';
echo '</script>';
			/*echo'<script>alert("INVALID USERNAME OR PASSWORD");</script>';*/
			header("Location:index.php");
			exit;
		}
	}
}
?>